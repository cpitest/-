

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import com.codeborne.selenide.Configuration;

import sbc.uitesttool.selenide.pageparts.AdminCorpAdd;
import sbc.uitesttool.selenide.pageparts.AdminCorpAddByContents;
import sbc.uitesttool.selenide.pageparts.AdminCorpAddByLite;
import sbc.uitesttool.selenide.pageparts.AdminCorpList;
import sbc.uitesttool.selenide.pageparts.AdminCorpMod;
import sbc.uitesttool.selenide.pageparts.AdminCorpUserAdd;
import sbc.uitesttool.selenide.pageparts.AdminDukeAdd;
import sbc.uitesttool.selenide.pageparts.AdminDukeList;
import sbc.uitesttool.selenide.pageparts.AdminDukeMod;
import sbc.uitesttool.selenide.pageparts.AdminHeader;
import sbc.uitesttool.selenide.pageparts.BizContract;
import sbc.uitesttool.selenide.pageparts.BizHeader;
import sbc.uitesttool.selenide.pageparts.BizLogin;
import sbc.uitesttool.selenide.report.ReportCsv;
import sbc.uitesttool.selenide.report.ScreenShot;
import sbc.uitesttool.selenide.report.records.CsvRecords;

//TODO:enumの処理共通化

@PageDoc("法人アカウント.法人アカウント一覧")
public class CorpListTest {
    // TODO:後で共通化する
    private static final String BASE_URL = "https://nwp.shcloudio.com/forBiz/admin/app";
    private static final String 法人向けログイン画面_URL = "https://nwp.shcloudio.com/forBiz/view/main/login.html";
    private static final String 個別法人画面_URL = "https://nwp.shcloudio.com/forBiz/view/main/adminbusinessuserlist.html";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

    @AfterClass
    public static void afterClass() {
	ReportCsv.outputCsv();
    }

    @Test
    public void 法人アカウント一覧のテスト_一覧表示() throws InterruptedException, IOException {
	open(BASE_URL);

    	//ScreenShot.takesScreenshot("法人アカウント一覧画面.png");

    //ID7_1_1_法人アカウント一覧に[ユーザー番号のプレフィックス]が表示されていること
		AdminCorpList.ユーザー番号のプレフィックス.スクロール();
		AdminCorpList.ユーザー番号のプレフィックス.表示文言を検証("))8");

		ReportCsv.chekedOK(CsvRecords.ID7_1_1_法人アカウント一覧表示確認);

    //ID7_1_2_法人アカウント一覧に[企業名]が表示されていること
		AdminCorpList.企業名.表示文言を検証("自動テスト");

		ReportCsv.chekedOK(CsvRecords.ID7_1_2_法人アカウント一覧表示確認);

    //ID7_1_3_法人アカウント編集画面にてタイトルに[法人アカウント編集]が表示されていること
		//AdminCorpMod.法人アカウント編集_タイトル.画像のaltを検証("法人アカウント編集");

		//ReportCsv.chekedOK(CsvRecords.ID7_1_3_法人アカウント編集_タイトル名);

    //ID7_1_4_法人アカウント編集画面にて[企業名]が表示されていること
		AdminCorpList.企業名.クリック();
		AdminCorpMod.企業名.セットされた値を検証("自動テスト");

		ReportCsv.chekedOK(CsvRecords.ID7_1_4_法人アカウント編集_企業名);

			ScreenShot.takesScreenshot("法人アカウント編集画面.png");

		AdminCorpMod.キャンセル.クリック();

		AdminCorpList.新規法人アカウントを追加ボタン.スクロール(); // ボタンのある位置までスクロール（スクロールしないとボタン押せない）
		AdminCorpList.新規法人アカウントを追加ボタン.クリック();

    //ID7_1_5_法人アカウント追加画面追加画面のタイトルに[法人アカウント追加画面追加]が表示されていること
		//AdminCorpAdd.法人アカウント追加_タイトル.画像のaltを検証;
		//ReportCsv.chekedOK(CsvRecords.ID7_1_5_法人アカウント追加_タイトル名);

    //ID7_1_6_法人アカウント追加画面にユーザー番号のプレフィックス_項目が表示されること
		AdminCorpAdd.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_6_法人アカウント追加_ユーザー番号のプレフィックス項目);

    //ID7_1_7_法人アカウント追加画面に企業名_項目が表示されること
		AdminCorpAdd.企業名_項目.表示文言を検証("企業名");

		ReportCsv.chekedOK(CsvRecords.ID7_1_7_法人アカウント追加_企業名項目);

    //ID7_1_8_法人アカウント追加画面にメールアドレス_項目が表示されること
		AdminCorpAdd.メールアドレス_項目.表示文言を検証("メールアドレス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_8_法人アカウント追加_メールアドレス項目);

    //ID7_1_9_法人アカウント追加画面にパスワード_項目が表示されること
		AdminCorpAdd.パスワード_項目.表示文言を検証("パスワード");

		//AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);
		//AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
		//AdminCorpAdd.パスワード_テキストボックス.セットされた値を検証("cpi12345");

		ReportCsv.chekedOK(CsvRecords.ID7_1_9_法人アカウント追加_パスワード項目);

    //ID7_1_10_法人アカウント追加画面に契約期間_項目が表示されること
		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

		ReportCsv.chekedOK(CsvRecords.ID7_1_10_法人アカウント追加_契約期間項目);

    //ID7_1_11_法人アカウント追加画面の最大登録数_項目が表示されること
		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

		ReportCsv.chekedOK(CsvRecords.ID7_1_11_法人アカウント追加_法人アカウント追加画面の最大登録数項目);

    //ID7_1_12_法人アカウント追加画面に法人種別_項目が表示されること
		AdminCorpAdd.法人種別_項目.表示文言を検証("法人種別");

		ReportCsv.chekedOK(CsvRecords.ID7_1_12_法人アカウント追加_法人種別項目);

    //ID7_1_13_法人アカウント追加画面にファイルロギング設定_項目が表示されること
		AdminCorpAdd.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_13_法人アカウント追加_ファイルロギング設定項目);

    //ID7_1_14_法人アカウント追加画面に_後課金_コピー機画面カスタマイズ設定項目が表示されること
		AdminCorpAdd.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_14_法人アカウント追加_後課金_コピー機画面カスタマイズ設定項目);

    //ID7_1_15_法人アカウント追加画面に_初回ログイン時パスワード強制変更項目が表示されること
		AdminCorpAdd.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

		ReportCsv.chekedOK(CsvRecords.ID7_1_15_法人アカウント追加_初回ログイン時パスワード強制変更項目);

    //ID7_1_16_法人アカウント追加画面に_アカウント設定禁止項目が表示されること
		AdminCorpAdd.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

		ReportCsv.chekedOK(CsvRecords.ID7_1_16_法人アカウント追加_アカウント設定禁止項目);

    //ID7_1_17_法人アカウント追加画面に_外部クラウドサービスとの連携項目が表示されること
		AdminCorpAdd.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

		ReportCsv.chekedOK(CsvRecords.ID7_1_17_法人アカウント追加_外部クラウドサービスとの連携項目);

			ScreenShot.takesScreenshot("法人アカウント追加画面.png");

    //ID7_1_18_ユーザー番号のプレフィックスに設定値が入力され正しく表示されていること
		AdminCorpAdd.ユーザー番号のプレフィックス.テキストに追記("]X1");
		AdminCorpAdd.ユーザー番号のプレフィックス.セットされた値を検証("]X1");

		ReportCsv.chekedOK(CsvRecords.ID7_1_18_法人アカウント追加_ユーザー番号のプレフィックス);

    //ID7_1_19_企業名に設定値が入力され正しく表示されていること
		AdminCorpAdd.企業名.テキストに追記("自動テスト1");
		AdminCorpAdd.企業名.セットされた値を検証("自動テスト1");

		ReportCsv.chekedOK(CsvRecords.ID7_1_19_法人アカウント追加_企業名);

    //ID7_1_20_メールアドレスに設定値が入力され正しく表示されていること
		AdminCorpAdd.メールアドレス.テキストに追記("autotesta1@test.test");
		AdminCorpAdd.メールアドレス.セットされた値を検証("autotesta1@test.test");

		ReportCsv.chekedOK(CsvRecords.ID7_1_20_法人アカウント追加_メールアドレス);

    //ID7_1_21_パスワードの入力が行えないこと
		AdminCorpAdd.パスワード_テキストボックス.編集不可状態であるかの検証(true);

		ReportCsv.chekedOK(CsvRecords.ID7_1_21_法人アカウント追加_パスワード入力不可);

    //ID7_1_22_パスワードのチェックボックスが有効にできること
		AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);

		ReportCsv.chekedOK(CsvRecords.ID7_1_22_法人アカウント追加_パスワード_チェックボックス);

    //ID7_1_23_パスワードの入力が行えること
		AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
		AdminCorpAdd.パスワード_テキストボックス.セットされた値を検証("cpi12345");

		ReportCsv.chekedOK(CsvRecords.ID7_1_23_法人アカウント追加_パスワード_テキストボックス);

    //ID7_1_24_契約期間に設定値が入力され正しく表示されていること
		AdminCorpAdd.契約期間.テキストを上書き("100");
		AdminCorpAdd.契約期間.セットされた値を検証("100");

		ReportCsv.chekedOK(CsvRecords.ID7_1_24_法人アカウント追加_契約期間);

    //ID7_1_25_法人アカウントの最大登録数に設定値が入力され正しく表示されていること
		AdminCorpAdd.法人アカウントの最大登録数.テキストを上書き("89");
		AdminCorpAdd.法人アカウントの最大登録数.セットされた値を検証("89");

		ReportCsv.chekedOK(CsvRecords.ID7_1_25_法人アカウント追加_法人アカウントの最大登録数);

    //ID7_1_26_法人種別forBiz用法人に設定されていること
		AdminCorpAdd.法人種別.Selectボックス選択("forBiz用法人");
		AdminCorpAdd.法人種別.表示文言を検証("forBiz用法人");

		ReportCsv.chekedOK(CsvRecords.ID7_1_26_法人アカウント追加_法人種別);

    //ID7_1_27_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること
		AdminCorpAdd.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_27_法人アカウント追加_ユーザー番号のプレフィックス_項目);

	//ID7_1_28_法人アカウント項目に企業名_項目が表示されていること
		AdminCorpAdd.企業名_項目.表示文言を検証("企業名");

		ReportCsv.chekedOK(CsvRecords.ID7_1_28_法人アカウント追加_企業名_項目);

    //ID7_1_29_法人アカウント項目にメールアドレス_項目が表示されていること
		AdminCorpAdd.メールアドレス_項目.表示文言を検証("メールアドレス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_29_法人アカウント追加_メールドレス_項目);

    //ID7_1_30_法人アカウント項目にパスワード_項目が表示されていること
		AdminCorpAdd.パスワード_項目.表示文言を検証("パスワード");

		ReportCsv.chekedOK(CsvRecords.ID7_1_30_法人アカウント追加_パスワード_項目);

    //ID7_1_31_法人アカウント項目に契約期間_項目が表示されていること
		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

		ReportCsv.chekedOK(CsvRecords.ID7_1_31_法人アカウント追加_契約期間_項目);

    //ID7_1_32_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
		AdminCorpAdd.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

		ReportCsv.chekedOK(CsvRecords.ID7_1_32_法人アカウント追加_法人アカウントの最大登録数_項目);

    //ID7_1_33_法人アカウント項目に法人種別_項目が表示されていること
		AdminCorpAdd.法人種別_項目.表示文言を検証("法人種別");

		ReportCsv.chekedOK(CsvRecords.ID7_1_33_法人アカウント追加_法人種別_項目);

    //ID7_1_34_法人アカウント項目にファイルロギング設定_項目が表示されていること
		AdminCorpAdd.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_34_法人アカウント追加_ファイルロギング設定_項目);

    //ID7_1_35_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
		AdminCorpAdd.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_35_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

    //ID7_1_36_法人アカウント項目に初回ログイン時パスワード強制変更_項目が表示されていること
		AdminCorpAdd.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

		ReportCsv.chekedOK(CsvRecords.ID7_1_36_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

    //ID7_1_37_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
		AdminCorpAdd.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_37_法人アカウント追加_パスワード有効期限設定_項目);

    //ID7_1_38_法人アカウント項目にアカウント設定禁止_項目が表示されていること
		AdminCorpAdd.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

		ReportCsv.chekedOK(CsvRecords.ID7_1_38_法人アカウント追加_アカウント設定禁止_項目);

    //ID7_1_39_法人アカウント項目に外部クラウドサービスとの連携_項目が表示されていること
		AdminCorpAdd.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

		ReportCsv.chekedOK(CsvRecords.ID7_1_39_法人アカウント追加_外部クラウドサービスとの連携_項目);

    //ID7_1_40_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_40_法人アカウント追加_法人アカウントの現在登録数_項目);

    //ID7_1_41_法人アカウント項目にクリックラップ契約_項目が非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_41_法人アカウント追加_クリックラップ契約_項目);

    //ID7_1_42_法人アカウント項目に印刷料金を価格情報ファイルから設定するが非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_42_法人アカウント追加_印刷料金を価格情報ファイルから設定);

    //ID7_1_43_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_43_法人アカウント追加_法人管理アカウント情報_項目);

	//ID7_1_44_法人種別forBizLite用法人が選択できること
		AdminCorpAdd.法人種別.Selectボックス選択("forBizLite用法人");

		ReportCsv.chekedOK(CsvRecords.ID7_1_44_法人アカウント追加_法人種別forBizLite用法人);

	//ID7_1_45_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること_forBizLite用法人
		AdminCorpAddByLite.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_45_法人アカウント追加_ユーザー番号のプレフィックス_項目);

    //ID7_1_46_法人アカウント項目に企業名_項目が表示されていること
		AdminCorpAddByLite.企業名_項目.表示文言を検証("企業名");

		ReportCsv.chekedOK(CsvRecords.ID7_1_46_法人アカウント追加_企業名_項目);

    //ID7_1_47_法人アカウント項目にメールアドレス_項目が表示されていること
		AdminCorpAddByLite.メールアドレス_項目.表示文言を検証("メールアドレス");

		ReportCsv.chekedOK(CsvRecords.ID7_1_47_法人アカウント追加_メールアドレス_項目);

    //ID7_1_48_法人アカウント項目にパスワード_項目が表示されていること
		AdminCorpAddByLite.パスワード_項目.表示文言を検証("パスワード");

		ReportCsv.chekedOK(CsvRecords.ID7_1_48_法人アカウント追加_パスワード_項目);

    //ID7_1_49_法人アカウント項目に契約期間_項目が表示されていること
		AdminCorpAddByLite.契約期間_項目.表示文言を検証("契約期間");

		ReportCsv.chekedOK(CsvRecords.ID7_1_49_法人アカウント追加_契約期間_項目);

    //ID7_1_50_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
		AdminCorpAddByLite.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

		ReportCsv.chekedOK(CsvRecords.ID7_1_50_法人アカウント追加_法人アカウントの最大登録数_項目);

    //ID7_1_51_法人アカウント項目に法人種別_項目が表示されていること
		AdminCorpAddByLite.法人種別_項目.表示文言を検証("法人種別");

		ReportCsv.chekedOK(CsvRecords.ID7_1_51_法人アカウント追加_法人種別_項目);

    //ID7_1_52_法人アカウント項目にファイルロギング設定_項目が表示されていること
		AdminCorpAddByLite.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_52_法人アカウント追加_ファイルロギング設定_項目);

    //ID7_1_53_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
		AdminCorpAddByLite.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_53_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

    //ID7_1_54_法人アカウント項目に初回ログイン時パスワード強制変更_項目が表示されていること
		AdminCorpAddByLite.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

		ReportCsv.chekedOK(CsvRecords.ID7_1_54_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

    //ID7_1_55_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
		AdminCorpAddByLite.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

		ReportCsv.chekedOK(CsvRecords.ID7_1_55_法人アカウント追加_パスワード有効期限設定_項目);

    //ID7_1_56_法人アカウント項目に印刷料金を価格情報ファイルから設定するが表示されていること
		AdminCorpAddByLite.印刷料金を価格情報ファイルから設定する_項目.表示文言を検証("印刷料金を価格情報ファイルから設定する");

		ReportCsv.chekedOK(CsvRecords.ID7_1_56_印刷料金を価格情報ファイルから設定_項目);

    //ID7_1_57_法人アカウント項目にアカウント設定禁止_項目が表示されていること
		AdminCorpAddByLite.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

		ReportCsv.chekedOK(CsvRecords.ID7_1_57_法人アカウント追加_アカウント設定禁止_項目);

    //ID7_1_58_法人アカウント項目に外部クラウドサービスとの連携_項目が表示されていること
		AdminCorpAddByLite.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

		ReportCsv.chekedOK(CsvRecords.ID7_1_58_法人アカウント追加_外部クラウドサービスとの連携_項目);

    //ID7_1_59_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_59_法人アカウント追加_法人アカウントの現在登録数_項目);

 	//ID7_1_60_法人アカウント項目にクリックラップ契約_項目が非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_60_法人アカウント追加_クリックラップ契約_項目);

    //ID7_1_61_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
		//ReportCsv.chekedOK(CsvRecords.ID7_1_61_法人アカウント追加_法人管理アカウント情報_項目);

	//ID7_1_62_法人種別コンテンツ利用用法人が選択できること
		AdminCorpAdd.法人種別.Selectボックス選択("コンテンツ利用用法人");

		ReportCsv.chekedOK(CsvRecords.ID7_1_62_法人アカウント追加_法人種別コンテンツ利用用法人);

    //ID7_1_63_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること_コンテンツ利用用法人
		AdminCorpAddByContents.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_63_法人アカウント追加_ユーザー番号のプレフィックス_項目);

    //ID7_1_64_法人アカウント項目に企業名_項目が表示されていること
 	  	AdminCorpAddByContents.企業名_項目.表示文言を検証("企業名");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_64_法人アカウント追加_企業名_項目);

    //ID7_1_65_法人アカウント項目にメールアドレス_項目が表示されていること
 	  	AdminCorpAddByContents.メールアドレス_項目.表示文言を検証("メールアドレス");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_65_法人アカウント追加_メールアドレス_項目);

    //ID7_1_66_法人アカウント項目にパスワード_項目が表示されていること
 	  	AdminCorpAddByContents.パスワード_項目.表示文言を検証("パスワード");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_66_法人アカウント追加_スワード_項目);

    //ID7_1_67_法人アカウント項目に契約期間_項目が表示されていること
 	  	AdminCorpAddByContents.契約期間_項目.表示文言を検証("契約期間");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_67_法人アカウント追加_契約期間_項目);

    //ID7_1_68_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
 	  	AdminCorpAddByContents.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

 	 	ReportCsv.chekedOK(CsvRecords.ID7_1_68_法人アカウント追加_法人アカウントの最大登録数_項目);

    //ID7_1_69_法人アカウント項目に法人種別_項目が表示されていること
 	 	AdminCorpAddByContents.法人種別_項目.表示文言を検証("法人種別");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_69_法人アカウント追加_法人種別_項目);

    //ID7_1_70_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
 	  	AdminCorpAddByContents.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_70_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

    //ID7_1_71_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
 	  	AdminCorpAddByContents.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_71_法人アカウント追加_パスワード有効期限設定_項目);

    //ID7_1_72_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_72_法人アカウント追加_法人アカウントの現在登録数_項目);

    //ID7_1_73_法人アカウント項目にクリックラップ契約_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_73_法人アカウント追加_クリックラップ契約_項目);

    //ID7_1_74_法人アカウント項目にファイルロギング設定_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_74_法人アカウント追加_ファイルロギング設定_項目);

    //ID7_1_75_法人アカウント項目に初回ログイン時パスワード強制変更_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_75_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

    //ID7_1_76_法人アカウント項目に印刷料金を価格情報ファイルから設定するが非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_76_法人アカウント追加_印刷料金を価格情報ファイルから設定_項目);

    //ID7_1_77_法人アカウント項目にアカウント設定禁止_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_77_法人アカウント追加_アカウント設定禁止_項目);

    //ID7_1_78_法人アカウント項目に外部クラウドサービスとの連携_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_78_法人アカウント追加_外部クラウドサービスとの連携_項目);

    //ID7_1_79_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_79_法人アカウント追加_法人管理アカウント情報_項目);

 	  	AdminCorpAddByContents.法人種別.Selectボックス選択("forBiz用法人");

    //ID7_1_80_法人アカウント項目_ファイルロギング設定のチェックボックスを無効にできること
 	  	AdminCorpAdd.ファイルロギング設定.チェックボックス選択(false);
 	  	AdminCorpAdd.ファイルロギング設定.チェックボックスがチェックされているかを検証(false);

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_80_法人アカウント追加_ファイルロギング設定);

    //ID7_1_81_法人アカウント項目_後課金_コピー機画面カスタマイズ設定のベンダー課金を選択できること
 	  	AdminCorpAdd.後課金_コピー機画面カスタマイズ設定.Selectボックス選択("ベンダー課金（標準価格）・標準設定");

 	  	ReportCsv.chekedOK(CsvRecords.ID7_1_81_法人アカウント追加_後課金_コピー機画面カスタマイズ設定);

    //ID7_1_82_forBiz用法人向けのappキーがリストに表示されること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_82_法人アカウント追加_forBiz用法人リスト);

    //ID7_1_83_forBizLite用法人向けのappキーがリストに表示されること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_83_法人アカウント追加_forBizLite用法人リスト);

    //ID7_1_84_コンテンツ利用用法人向けのappキーがリストに表示されること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_84_法人アカウント追加_コンテンツ利用法人リスト);

    //ID7_1_85_appキーの追加_削除が可能であること
 	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_85_法人アカウント追加_appキー追加_削除);

    //ID7_1_86_初回ログイン時パスワード強制変更のチェックボックスを無効にできること
    	AdminCorpAdd.初回ログイン時パスワード強制変更.チェックボックス選択(false);
    	AdminCorpAdd.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(false);

    ReportCsv.chekedOK(CsvRecords.ID7_1_86_法人アカウント追加_初回ログイン時パスワード強制変更);

    //ID7_1_88_パスワード有効期限設定のチェックボックスを無効にできること
    	AdminCorpAdd.パスワード有効期限設定.チェックボックス選択(false);
    	AdminCorpAdd.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

    ReportCsv.chekedOK(CsvRecords.ID7_1_88_法人アカウント追加_パスワード有効期限設定);

    //ID7_1_90_アカウント設定禁止のチェックボックスを無効にできること
    	AdminCorpAdd.アカウント設定禁止.チェックボックス選択(false);
    	AdminCorpAdd.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);

    ReportCsv.chekedOK(CsvRecords.ID7_1_90_法人アカウント追加_アカウント設定禁止);

    //ID7_1_92_外部クラウドサービスとの連携を[指定しない]に選択できること
    	AdminCorpAdd.外部クラウドサービスとの連携.Selectボックス選択("指定しない");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_92_法人アカウント追加_外部クラウドサービスとの連携);

    		ScreenShot.takesScreenshot("法人アカウント追加画面.png");

    //ID7_1_94_[この設定を登録する]ボタンの選択が有効であること
    	AdminCorpAdd.この設定を登録する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);

    	//AdminCorpAdd.キャンセル.クリック();//本番時に削除または不要にする

    	ReportCsv.chekedOK(CsvRecords.ID7_1_94_法人アカウント追加_登録ボタン);

    	Thread.sleep(20000);	//wait

    //ID7_1_95_法人アカウント一覧画面に遷移すること
    	AdminCorpList.新規法人アカウントを追加ボタン.スクロール();

    	ReportCsv.chekedOK(CsvRecords.ID7_1_95_法人アカウント一覧画面);

    //ID7_1_96_作成した法人アカウントの[ユーザー番号のプレフィックス]が一覧に表示されていること
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人プレフィックス.表示文言を検証("]X1");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_96_法人アカウント一覧画面_ユーザー番号のプレフィックス);

    //ID7_1_97_作成した法人アカウントの[企業名]が一覧に表示されること
    	AdminCorpList.forBiz用法人企業名.表示文言を検証("自動テスト1");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_97_法人アカウント一覧画面_企業名);
		Thread.sleep(5000); // スクロール待ち


    //ID7_1_98_作成した法人アカウントの[企業名]が選択できること
		Thread.sleep(5000); // スクロール待ち
    	AdminCorpList.forBiz用法人企業名.クリック();

    	ReportCsv.chekedOK(CsvRecords.ID7_1_98_法人アカウント一覧画面_企業名選択);

    		ScreenShot.takesScreenshot("法人アカウント新規作成_編集画面.png");

    //ID7_1_99_登録したユーザー番号のプレフィクスが反映されること
    	AdminCorpMod.ユーザー番号のプレフィックス.セットされた値を検証("]X1");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_99_法人アカウント編集_ユーザー番号のプレフィックス);

    //ID7_1_100_登録した企業名が反映されること
    	AdminCorpMod.企業名.セットされた値を検証("自動テスト1");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_100_法人アカウント一覧画面_企業名);

    //ID7_1_101_登録したメールアドレスが反映されること
    	AdminCorpMod.メールアドレス.スクロール();
    	AdminCorpMod.メールアドレス.表示文言を検証("autotesta1@test.test");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_101_法人アカウント編集_メールアドレス);

    //ID7_1_102_登録した法人アカウントの現在登録数が表示されること
    	AdminCorpMod.法人アカウントの現在登録数.表示文言を検証("0");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_102_法人アカウント編集_法人アカウントの現在登録数);

    //ID7_1_103_登録した法人アカウントの最大登録数が反映されること
    	AdminCorpMod.法人アカウントの最大登録数.セットされた値を検証("89");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_103_法人アカウント編集_法人アカウントの最大登録数);

    //ID7_1_104_登録した法人種別が反映されること
    	AdminCorpMod.法人種別.表示文言を検証("forBiz用法人");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_104_法人アカウント編集_法人種別);

    //ID7_1_107_登録した契約期間が反映されること
    	AdminCorpMod.契約期間.セットされた値を検証("100");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_107_法人アカウント編集_契約期間);

    //ID7_1_108_登録したファイルロギング設定が反映されること
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_108_法人アカウント編集_ファイルロギング設定);

    //ID7_1_110_登録した後課金/コピー機画面カスタマイズ設定が反映されること
    	AdminCorpMod.後課金_コピー機画面カスタマイズ設定.表示文言を検証("ベンダー課金（標準価格）・標準設定");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_110_法人アカウント編集_後課金_コピー機画面カスタマイズ設定);

    //ID7_1_111_クリックラップ契約の初期値が有効であること
    	AdminCorpMod.クリックラップ契約.チェックボックスがチェックされているかを検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_111_法人アカウント編集_クリックラップ契約);

    //ID7_1_113_登録した初回ログイン時パスワード強制変更が反映されること
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_113_法人アカウント編集_初回ログイン時パスワード強制変更);

    //ID7_1_115_登録したパスワード有効期限設定が反映されること
    	AdminCorpMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_115_法人アカウント編集_パスワード有効期限設定);

    //ID7_1_117_登録したアカウント設定禁止が反映されること
    	AdminCorpMod.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_117_法人アカウント編集_アカウント設定禁止);

    //ID7_1_119_登録した外部クラウドサービスとの連携が[設定しない]となっていること
    	AdminCorpMod.外部クラウドサービスとの連携.表示文言を検証("指定しない");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_119_法人アカウント編集_外部クラウドサービス);

    	ScreenShot.takesScreenshot("ID7_1_119_登録した外部クラウドサービスとの連携が[設定しない]となっていること.png");

    	AdminCorpMod.キャンセル.クリック();

    	AdminCorpList.新規法人アカウントを追加ボタン.スクロール();
    	AdminCorpList.新規法人アカウントを追加ボタン.クリック();

    //ID7_1_105_登録した法人種別_forBizLite用法人が反映されること
    	AdminCorpAdd.ユーザー番号のプレフィックス.テキストを上書き("]X2");
    	AdminCorpAdd.企業名.テキストを上書き("自動テスト2");
    	AdminCorpAdd.法人種別.Selectボックス選択("forBizLite用法人");
    	AdminCorpAdd.メールアドレス.テキストを上書き("autotesta2@test.test");
    	AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);
    	AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
    	AdminCorpAdd.法人アカウントの最大登録数.テキストを上書き("10");
    	AdminCorpAdd.ファイルロギング設定.チェックボックス選択(true);


    //ID7_1_87_初回ログイン時パスワード強制変更のチェックボックスを有効にできること
    	AdminCorpAdd.初回ログイン時パスワード強制変更.チェックボックス選択(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_87_法人アカウント追加_初回ログイン時パスワード強制変更);


    //ID7_1_89_パスワード有効期限設定のチェックボックスを有効にできること
    	AdminCorpAdd.パスワード有効期限設定.チェックボックス選択(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_89_法人アカウント追加_パスワード有効期限設定);


    //ID7_1_91_アカウント設定禁止のチェックボックスを有効にできること
    	AdminCorpAdd.アカウント設定禁止.チェックボックス選択(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_91_法人アカウント追加_アカウント設定禁止);

    //ID7_1_93_外部クラウドサービスとの連携で[Dropbox]が選択できること
    	AdminCorpAdd.外部クラウドサービスとの連携.Selectボックス選択("Dropbox");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_93_法人アカウント追加_外部クラウドサービスとの連携);

    	AdminCorpAdd.この設定を登録する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);

       	Thread.sleep(20000);	//wait
    //ID7_1_105_登録した法人種別_forBizLite用法人が反映されること
    	AdminCorpList.forBizLite用法人プレフィックス.スクロール();
    	AdminCorpList.forBizLite用法人企業名.クリック();

    	//AdminCorpModByLite.法人種別.表示文言を検証("forBizLite用法人");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_105_法人アカウント編集_法人種別);

    //ID7_1_109_登録したファイルロギング設定の設定値が有効であること
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_109_法人アカウント編集_ファイルロギング設定);

    //ID7_1_114_登録した初回ログイン時パスワード強制変更のチェックボックスが有効となっていること
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_114_法人アカウント編集_初回ログイン時パスワード強制変更);

    //ID7_1_116_登録したパスワード有効期限設定のチェックボックスが有効となっていること
    	AdminCorpMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_116_法人アカウント編集_パスワード有効期限設定);

    //ID7_1_118_登録したアカウント設定禁止のチェックボックスが有効となっていること
    	AdminCorpMod.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_118_法人アカウント編集_アカウント設定禁止);

    //ID7_1_120_登録した外部クラウドサービスとの連携が[Dropbox]となっていること
    	AdminCorpMod.外部クラウドサービスとの連携.表示文言を検証("Dropbox");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_120_法人アカウント編集_外部クラウドサービス);

    	AdminCorpAdd.キャンセル.クリック();

    //ID7_1_106_登録した法人種別_コンテンツ利用用法人が反映されること
    	AdminCorpList.新規法人アカウントを追加ボタン.スクロール();
    	AdminCorpList.新規法人アカウントを追加ボタン.クリック();

    	AdminCorpAdd.法人種別.Selectボックス選択("コンテンツ利用用法人");
    	AdminCorpAdd.ユーザー番号のプレフィックス.テキストを上書き("]X3");
    	AdminCorpAdd.企業名.テキストを上書き("自動テスト3");
    	AdminCorpAdd.メールアドレス.テキストを上書き("autotesta3@test.test");
    	AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);
    	AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
    	AdminCorpAdd.法人アカウントの最大登録数.テキストを上書き("10");
    	AdminCorpAdd.追加.クリック();

    	AdminCorpAdd.この設定を登録する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
       	Thread.sleep(20000);	//wait

    	AdminCorpList.コンテンツ利用用法人プレフィックス.スクロール();
    	AdminCorpList.コンテンツ利用用法人企業名.クリック();

    	AdminCorpMod.法人種別.表示文言を検証("コンテンツ利用用法人");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_106_法人アカウント編集_法人種別);

    //ID7_1_112_クリックラップ契約のチェックボックスが無効であること
    	open(法人向けログイン画面_URL);

    	BizLogin.ログイン名.テキストを上書き("autotesta1@test.test");
    	BizLogin.パスワード.テキストを上書き("cpi12345");
    	BizLogin.ログインボタン.クリック();

    	ScreenShot.takesScreenshot("ID7_1_112_クリックラップ契約のチェックボックスが無効であること.png");

    	BizContract.同意チェックボックス.チェックボックス選択(true);
    	BizContract.OKボタン.クリック();


    	open(BASE_URL);
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();

    	AdminCorpMod.クリックラップ契約.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_112_法人アカウント編集_クリックラップ契約);

    	AdminCorpMod.キャンセル.クリック();

    //ID7_1_121_テキストボックスがグレーアウト表示されていること
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();

    	ScreenShot.takesScreenshot("ID7_1_121_法人アカウント編集_ユーザー番号とプレフィックス_グレーアウト表示.png");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_121_法人アカウント編集_ユーザー番号とプレフィックス_グレーアウト表示);


   	//ID7_1_122_テキストボックスが変更不可であること
    	AdminCorpMod.ユーザー番号のプレフィックス.編集不可状態であるかの検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_122_法人アカウント編集_ユーザー番号とプレフィックス_編集不可);

   	//ID7_1_123_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpMod.企業名.テキストを上書き("]X1編集");
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_123_法人アカウント編集_企業名);

	//ID7_1_124_法人アカウント一覧に編集した企業名が反映されていること
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人企業名_編集.表示文言を検証("]X1編集");

       	ReportCsv.chekedOK(CsvRecords.ID7_1_124_法人アカウント編集_アカウント一覧_企業名);

    //ID7_1_125_再度編集画面へ遷移し、編集した企業名が反映されていること
    	AdminCorpList.forBiz用法人企業名_編集.クリック();
    	AdminCorpMod.企業名.セットされた値を検証("]X1編集");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_125_法人アカウント編集後_企業名);

    	AdminCorpMod.企業名.テキストを上書き("自動テスト1");
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

   	//ID7_1_126_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.ファイルロギング設定.チェックボックス選択(false);
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(false);

    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_126_法人アカウント編集_ファイルロギング設定);

	//ID7_1_127_再度編集画面へ遷移しファイルロギング設定のチェックボックスが有効となっていること
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(false);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_127_法人アカウント編集_アカウント一覧_ファイルロギング設定_無効);

   	//ID7_1_128_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpMod.ファイルロギング設定.チェックボックス選択(true);
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(true);

    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_128_法人アカウント編集_ファイルロギング設定);

    //ID7_1_129_再度編集画面へ遷移しファイルロギング設定のチェックボックスが無効となっていること
    	AdminCorpList.forBiz用法人プレフィックス.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.ファイルロギング設定.チェックボックスがチェックされているかを検証(true);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_129_法人アカウント編集_アカウント一覧_ファイルロギング設定_有効);

    	AdminCorpMod.キャンセル.クリック();


    //ID7_1_130_forBiz用法人向けのappキーがリストに表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_130_法人アカウント編集_後課金/コピー機画面カスタマイズ設定_forBiz);

   	//ID7_1_131_forBizLite用法人向けのappキーがリストに表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_131_法人アカウント編集_後課金/コピー機画面カスタマイズ設定_forBizLite);

   	//ID7_1_132_コンテンツ利用用法人向けのappキーがリストに表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_132_法人アカウント編集_後課金/コピー機画面カスタマイズ設定_コンテンツ利用);

   	//ID7_1_133_appキーの追加/削除が可能であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_133_法人アカウント編集_後課金/コピー機画面カスタマイズ設定_appキー);

   	//ID7_1_134_appキーが反映されていること（編集画面で確認）
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_134_法人アカウント編集_後課金/コピー機画面カスタマイズ設定_appキー);

   	//ID7_1_135_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();

    	AdminCorpMod.クリックラップ契約.チェックボックスがチェックされているかを検証(false);
    	AdminCorpMod.クリックラップ契約.チェックボックス選択(true);

    	ScreenShot.takesScreenshot("ID7_1_135_[この設定で変更]にて、法人編集可能なこと.png");

    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	AdminCorpList.forBiz用法人企業名.スクロール();

    	ReportCsv.chekedOK(CsvRecords.ID7_1_135_法人アカウント編集_クリックラップ契約);

   	//ID7_1_136_企業用ページにログイン時、利用規約画面を表示する
    	open(法人向けログイン画面_URL);

    	BizLogin.ログイン名.テキストを上書き("autotesta1@test.test");
    	BizLogin.パスワード.テキストを上書き("cpi12345");
    	BizLogin.ログインボタン.クリック();

    	ScreenShot.takesScreenshot("ID7_1_136_企業用ページにログイン時、利用規約画面を表示する.png");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_136_法人アカウント編集_クリックラップ契約_利用規約);

    	//ID7_1_137_[この設定で変更]にて、法人編集可能なこと
    	open(BASE_URL);

    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.パスワード有効期限設定.チェックボックス選択(true);
    	AdminCorpMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_139_初回ログイン時パスワード強制変更_無効から有効);

    	//ID7_1_140_作成した法人ユーザー初回ログイン時にパスワード変更画面が表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_140_初回ログイン時パスワード強制変更_無効から有効);

    //ID7_1_141_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックス選択(false);
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(false);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_141_初回ログイン時パスワード強制変更_有効から無効);

    //ID7_1_142_作成した法人ユーザー初回ログイン時にパスワード変更画面が表示されないこと
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_142_初回ログイン時パスワード強制変更_有効から無効);

    //ID7_1_143_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックス選択(true);
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(true);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_143_パスワード有効期限設定_パスワード有効期限設定);

    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックス選択(false);
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(false);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    //ID7_1_144_ユーザーで、パスワード有効期限が切れた場合(180日経過後)、パスワード変更画面が表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_144_パスワード有効期限設定_パスワード有効期限設定);

    //ID7_1_145_ユーザーで、パスワード有効期限2日前にメールが送られてくること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_145_パスワード有効期限設定_パスワード有効期限設定);

    //ID7_1_146_管理者で、パスワード有効期限が切れた場合(180日経過後)、パスワード変更画面が表示されること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_146_パスワード有効期限設定_パスワード有効期限設定);

    //ID7_1_147_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);
    	AdminCorpMod.パスワード有効期限設定.チェックボックス選択(false);
    	AdminCorpMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_147_パスワード有効期限設定_パスワード有効期限設定);

    //ID7_1_148_180日経過後、パスワード変更画面が表示されないこと
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_148_パスワード有効期限設定_パスワード有効期限設定);

    //ID7_1_149_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);
    	AdminCorpMod.アカウント設定禁止.チェックボックス選択(true);
    	AdminCorpMod.アカウント設定禁止.チェックボックスがチェックされているかを検証(true);
    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_149_法人アカウント設定禁止_無効から有効);

    	//ID7_1_150_法人作成不可能なこと
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_150_法人アカウント設定禁止_無効から有効);

    //ID7_1_151_法人管理者画面ログイン後「一般アカウント」が非表示であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_151_法人アカウント設定禁止_無効から有効);

    //ID7_1_152_法人管理者画面ログイン後「共有ボックス」項目が非表示であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_152_法人アカウント設定禁止_無効から有効);

    //ID7_1_153_[この設定で変更]にて、法人編集可能なこと
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.パスワード有効期限設定.チェックボックス選択(false);
    	AdminCorpMod.初回ログイン時パスワード強制変更.チェックボックス選択(false);
    	AdminCorpMod.アカウント設定禁止.チェックボックス選択(false);
    	AdminCorpMod.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);

    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	ReportCsv.chekedOK(CsvRecords.ID7_1_153_法人アカウント設定禁止_有効から無効);

    //ID7_1_154_法人作成可能なこと
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_154_法人アカウント設定禁止_有効から無効);
    	AdminCorpList.forBiz用法人企業名.スクロール();
    	AdminCorpList.forBiz用法人企業名.クリック();
    	AdminCorpMod.アカウント設定禁止.チェックボックス選択(false);
    	AdminCorpMod.外部クラウドサービスとの連携.Selectボックス選択("Dropbox");

    	AdminCorpMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

    	AdminCorpList.forBiz用法人企業名.スクロール();

    	//ID7_1_155_法人管理者画面ログイン後「一般アカウント」項目が表示されていること
    	open(法人向けログイン画面_URL);

	BizLogin.ログイン名.テキストを上書き("autotesta1@test.test");
	BizLogin.パスワード.テキストを上書き("cpi12345");
	BizLogin.ログインボタン.クリック();

	BizContract.同意チェックボックス.チェックボックス選択(true);
	BizContract.OKボタン.クリック();

	BizHeader.企業情報_ON.表示文言を検証("企業情報");
	BizHeader.管理者アカウント.表示文言を検証("管理者アカウント");
	BizHeader.一般アカウント.表示文言を検証("一般アカウント");
	BizHeader.利用状況取得.表示文言を検証("利用状況取得");
	BizHeader.ファイル管理.表示文言を検証("ファイル管理");

	ReportCsv.chekedOK(CsvRecords.ID7_1_155_法人アカウント設定禁止_有効から無効);

//ID7_1_156_法人管理者画面ログイン後「共有ボックス」項目が表示されていること
   	BizHeader.共有ボックス.表示文言を検証("共有ボックス");

	ReportCsv.chekedOK(CsvRecords.ID7_1_156_法人アカウント設定禁止_有効から無効);

//ID7_1_157_[この設定で変更]にて、法人編集可能なこと
	open(BASE_URL);

	AdminCorpList.forBiz用法人企業名.スクロール();
	AdminCorpList.forBiz用法人企業名.クリック();
	AdminCorpMod.外部クラウドサービスとの連携.Selectボックス選択("指定しない");
	AdminCorpMod.この設定で変更する.クリック();
    AdminDukeList.確認ダイアログのボタン押下(true);
    Thread.sleep(2000);


	ReportCsv.chekedOK(CsvRecords.ID7_1_157_外部クラウドサービスとの連携_Dropboxから設定しない);

//ID7_1_158_再度編集画面へ遷移し、外部クラウドサービスとの連携設定が反映されていること

	AdminCorpList.forBiz用法人企業名.スクロール();
	AdminCorpList.forBiz用法人企業名.クリック();
	AdminCorpMod.外部クラウドサービスとの連携.表示文言を検証("指定しない");

	ReportCsv.chekedOK(CsvRecords.ID7_1_158_外部クラウドサービスとの連携_Dropboxから設定しない);

//ID7_1_159_[この設定で変更]にて、法人編集可能なこと
	AdminCorpMod.外部クラウドサービスとの連携.Selectボックス選択("Dropbox");
	AdminCorpMod.この設定で変更する.クリック();
    AdminDukeList.確認ダイアログのボタン押下(true);
    Thread.sleep(2000);

	ReportCsv.chekedOK(CsvRecords.ID7_1_159_外部クラウドサービスとの連携_設定しなからからDropbox);

//ID7_1_160_再度編集画面へ遷移し、外部クラウドサービスとの連携設定が反映されていること
	AdminCorpList.forBiz用法人企業名.スクロール();
	AdminCorpList.forBiz用法人企業名.クリック();
	AdminCorpMod.外部クラウドサービスとの連携.表示文言を検証("Dropbox");

	ReportCsv.chekedOK(CsvRecords.ID7_1_160_外部クラウドサービスとの連携_設定しないからDropbox);

//ID7_1_161_ファイル作成用マクロにて出力したjsonファイルを選択してインポート可能であること
	//ReportCsv.chekedOK(CsvRecords.ID7_1_161_印刷料金を価格情報ファイルから設定する_ファイル選択);

//ID7_1_162_「価格情報ファイル作成用マクロはこちら」リンクよりマクロがDL可能であること
	//ReportCsv.chekedOK(CsvRecords.ID7_1_162_印刷料金を価格情報ファイルから設定する_価格情報マクロDL);

//ID7_1_163_「料金テーブル」ダイアログが表示されること
	//ReportCsv.chekedOK(CsvRecords.ID7_1_163_印刷料金を価格情報ファイルから設定する_印刷料金を確認);

//ID7_1_164_登録済みの管理者アカウントが表示されていること
	AdminCorpMod.メールアドレス.表示文言を検証("autotesta1@test.test");

	ReportCsv.chekedOK(CsvRecords.ID7_1_164_法人管理アカウント情報);

//ID7_1_165_[削除]にて管理者アカウントの削除が可能であること
	//ReportCsv.chekedOK(CsvRecords.ID7_1_165_法人管理アカウント情報_削除);

//ID7_1_166_法人管理者画面にて削除した管理者アカウントでログインできないこと
	//open(法人向けログイン画面_URL);

	//BizLogin.ログイン名.テキストを上書き("");
	//BizLogin.パスワード.テキストを上書き("");
	//BizLogin.ログインボタン.クリック();
	//BizLogin.ログイン失敗メッセージ.表示文言を検証("※ネットワークプリントサービスにログインできませんでした。ログイン名またはパスワードに間違いがないかご確認ください。");

	//ReportCsv.chekedOK(CsvRecords.ID7_1_166_法人管理アカウント情報_削除アカウント);

//ID7_1_167_法人アカウント追加画面に遷移できること
   	AdminCorpMod.管理者アカウントを追加する.クリック();


	ReportCsv.chekedOK(CsvRecords.ID7_1_167_法人管理アカウント追加);

//ID7_1_168_メールアドレス/パスワードを指定し追加可能であること
   	AdminCorpUserAdd.メールアドレス.テキストを上書き("at1no1@test.test");
	AdminCorpUserAdd.パスワード_チェックボックス.チェックボックス選択(false);
	AdminCorpUserAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
	AdminCorpUserAdd.この設定で登録する.クリック();
    AdminDukeList.確認ダイアログのボタン押下(true);
    Thread.sleep(2000);

	ReportCsv.chekedOK(CsvRecords.ID7_1_168_法人管理アカウント追加_アカウント);

//ID7_1_169_法人アカウント編集画面に追加した管理者アカウント情報が表示されること
	AdminCorpMod.メールアドレス.表示文言を検証("at1no1@test.test");
	AdminCorpMod.この設定で変更する.クリック();
    AdminDukeList.確認ダイアログのボタン押下(true);
    Thread.sleep(2000);

	ReportCsv.chekedOK(CsvRecords.ID7_1_169_法人管理アカウント追加_管理者アカウント);

	AdminCorpList.forBiz用法人企業名.スクロール();

    //ID7_1_170_追加した管理者アカウントで管理者ページにログインできること
    	open(法人向けログイン画面_URL);

    	BizLogin.ログイン名.テキストを上書き("at1no1@test.test");
    	BizLogin.パスワード.テキストを上書き("cpi12345");
    	BizLogin.ログインボタン.クリック();

    	ScreenShot.takesScreenshot("ID7_1_170_追加した管理者アカウントで管理者ページにログインできること.png");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_170_法人管理アカウント追加_管理者ログイン);

    //ID7_1_171_ファイル作成用マクロにて出力したjsonファイルを選択してインポート可能であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_171_印刷料金を価格情報ファイルから設定する);

    //ID7_1_172_「価格情報ファイル作成用マクロはこちら」リンクよりマクロがDL可能であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_172_印刷料金を価格情報ファイルから);

    //ID7_1_173_法人の削除予約が可能であること
    	//ReportCsv.chekedOK(CsvRecords.ID7_1_173_法人削除);

        //ID7_1_174_個別アカウント一覧にユーザー番号が表示されていること
    	open(個別法人画面_URL);

    	AdminHeader.ヘッダー_個別アカウント_ON.クリック();
    	AdminDukeList.ユーザー番号0.表示文言を検証("()+.-;[]~=");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_174_個別アカウント一覧画面_ユーバー番号);

    //ID7_1_175_個別アカウント一覧にニックネームが表示されていること
    	AdminDukeList.ニックネーム0.表示文言を検証("きごう");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_175_個別アカウント一覧画面_ニックネーム);

   	//ID7_1_176_個別アカウント一覧にログイン名(メールアドレス)が表示されていること
    	AdminDukeList.ログイン名0.表示文言を検証("kigou@kigoumaru.com");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_176_個別アカウント一覧画面_ログイン名);

   	//ID7_1_177_[新規個別アカウントを追加]ボタンが選択できること
    	AdminDukeList.新規個別アカウントを追加.スクロール();
    	AdminDukeList.新規個別アカウントを追加.クリック();

    	ReportCsv.chekedOK(CsvRecords.ID7_1_177_個別カウント一覧画面_アカウント追加);

    //ID7_1_178_個別アカウント追加画面へ遷移すること
    	ScreenShot.takesScreenshot("ID7_1_178_個別アカウント追加画面へ遷移すること.png");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_178_個別アカウント追加画面);

    //ID7_1_179_個別アカウント項目にユーザー番号が表示されていること
    	AdminDukeAdd.ユーザー番号_項目.表示文言を検証("ユーザー番号");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_179_個別アカウント追加画面_ユーザー番号);

    //ID7_1_180_個別アカウント項目にログイン名(メールアドレス)が表示されていること
    	AdminDukeAdd.ログイン名_メールアドレス_項目.表示文言を検証("ログイン名(メールアドレス)");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_180_個別アカウント追加画面_ログイン名);

    //ID7_1_181_個別アカウント項目にパスワードが表示されていること
    	AdminDukeAdd.パスワード_項目.表示文言を検証("パスワード");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_181_個別アカウント追加画面_パスワード);

    //ID7_1_182_個別アカウント項目にニックネームが表示されていること
    	AdminDukeAdd.ニックネーム_項目.表示文言を検証("ニックネーム");

        ReportCsv.chekedOK(CsvRecords.ID7_1_182_個別アカウント追加画面_ニックネーム);

    //ID7_1_183_個別アカウント項目にファイル保管日数が表示されていること
    	AdminDukeAdd.ファイル保管日数_項目.表示文言を検証("ファイル保管日数");

        ReportCsv.chekedOK(CsvRecords.ID7_1_183_個別アカウント追加画面_ファイル保存日数);

    //ID7_1_184_個別アカウント項目に店舗にあるマルチコピー機でのログイン方法が表示されていること
    	AdminDukeAdd.店舗にあるマルチコピー機でのログイン方法_項目.表示文言を検証("店舗にあるマルチコピー機でのログイン方法");

        ReportCsv.chekedOK(CsvRecords.ID7_1_184_個別アカウント追加画面_ログイン方法);

    //ID7_1_185_個別アカウント項目に後課金_コピー機画面カスタマイズ設定が表示されていること
    	AdminDukeAdd.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_185_個別アカウント追加画面_後課金_コピー機画面カスタマイズ設定);

    //ID7_1_186_個別アカウント項目にパスワード有効期限設定が表示されていること
    	AdminDukeAdd.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_186_個別アカウント追加画面_パスワード有効期限設定);

    //ID7_1_187_ユーザー番号に指定した内容が入力できること
    	AdminDukeAdd.ユーザー番号.テキストを上書き(")A10000001");

        ReportCsv.chekedOK(CsvRecords.ID7_1_187_個別アカウント追加画面_ユーザー番号);

    //ID7_1_190_ログイン名(メールアドレス）に指定した内容が入力できること
    	AdminDukeAdd.ログイン名_メールアドレス.テキストを上書き("autouser1@test.test");

        ReportCsv.chekedOK(CsvRecords.ID7_1_190_個別アカウント追加画面_ログイン名);

    //ID7_1_193_パスワードに指定した内容が入力できること
    	AdminDukeAdd.パスワード.テキストを上書き("cpi12345");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_193_個別アカウント追加画面_パスワード);

    //ID7_1_195_ニックネームに指定した内容が入力できること
    	AdminDukeAdd.ニックネーム.テキストを上書き("自動個別アカウント");

        ReportCsv.chekedOK(CsvRecords.ID7_1_195_個別アカウント追加画面_ニックネーム);

    //ID7_1_198_ファイル保管日数に指定した内容が入力できること
    	AdminDukeAdd.ファイル保管日数.テキストを上書き("10");

        ReportCsv.chekedOK(CsvRecords.ID7_1_198_個別アカウント追加画面_ファイル保管日数);

    //ID7_1_199_ファイル保管日数内のファイルが削除されないこと
        	//ReportCsv.chekedOK(CsvRecords.ID7_1_199_ファイル保管日数_期限内);

    //ID7_1_200_ファイル保管日数経過でファイルが削除されること
        	//ReportCsv.chekedOK(CsvRecords.ID7_1_200_ファイル保管日数_期限経過);

    //ID7_1_201_「ユーザー番号のみまたはログイン名とパスワードでログインする。」が選択できること
    	AdminDukeAdd.店舗にあるマルチコピー機でのログイン方法_番号とログイン名.チェックボックス選択(true);
    	AdminDukeAdd.店舗にあるマルチコピー機でのログイン方法_番号とログイン名.チェックボックスがチェックされているかを検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_201_個別アカウント追加画面_ログイン方法);

     //ID7_1_202_「ユーザー番号のみでのログインを禁止し、常にログイン名とパスワードでログインする。」が選択できること
    	AdminDukeAdd.店舗にあるマルチコピー機でのログイン方法_ログイン名のみ.チェックボックス選択(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_202_個別アカウント追加画面_ログイン方法);

     //ID7_1_203_(appdb)prnsys_appkey_costmizeのappキーがリストに表示されること
        	//ReportCsv.chekedOK(CsvRecords.ID7_1_203_個別アカウント追加画面_後課金_コピー機画面カスタマイズ設定);

     //ID7_1_204_パスワードの有効期限(180日間)を設定するのチェックボックスが無効にできること
    	AdminDukeAdd.パスワード有効期限設定.チェックボックス選択(false);
    	AdminDukeAdd.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

        ReportCsv.chekedOK(CsvRecords.ID7_1_204_個別アカウント追加画面_パスワードの有効期限_無効);

     //ID7_1_205_パスワードの有効期限(180日間)を設定するのチェックボックスが有効にできること
    	AdminDukeAdd.パスワード有効期限設定.チェックボックス選択(true);
    	AdminDukeAdd.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_205_個別アカウント追加画面_パスワードの有効期限_有効);

     //ID7_1_206_[この設定を登録する]ボタンの選択が有効であること
    	AdminDukeAdd.この設定を登録する.スクロール();
    	AdminDukeAdd.この設定を登録する.クリック();
    	AdminDukeList.確認ダイアログのボタン押下(true);
    	Thread.sleep(2000);

        ReportCsv.chekedOK(CsvRecords.ID7_1_206_個別アカウント追加画面_設定登録);

     //ID7_1_207_個別アカウント一覧画面に遷移すること
    	AdminDukeList.ユーザー番号0.表示文言を検証("()+.-;[]~=");
    	AdminDukeList.新規個別アカウントを追加.スクロール();
    	AdminDukeList.新規個別アカウントを追加_項目.表示文言を検証("新規個別アカウントを追加");

        ReportCsv.chekedOK(CsvRecords.ID7_1_207_個別アカウント追加画面_設定登録後);

     //ID7_1_208_作成した個別アカウントの[ユーザー番号]が一覧に表示されていること
        AdminDukeList.ページ選択.Selectボックス選択("5");
    	AdminDukeList.ユーザー番号1.表示文言を検証(")A10000001");

        	ReportCsv.chekedOK(CsvRecords.ID7_1_208_登録後_ユーザー番号表示);

     //ID7_1_209_作成した個別アカウントの[ログイン名（メールアドレス）]が一覧に表示されること
    	AdminDukeList.ログイン名1.表示文言を検証("autouser1@test.test");

        ReportCsv.chekedOK(CsvRecords.ID7_1_209_登録後_ログイン名);

     //ID7_1_210_作成した個別アカウントの[ニックネーム]が選択できること
    	AdminDukeList.ニックネーム1.スクロール();
    	AdminDukeList.ニックネーム1.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_210_登録後_ニックネーム);

     //ID7_1_211_作成した個別アカウントの[ユーザー番号]が選択できること
    	AdminDukeList.ユーザー番号1.スクロール();
    	AdminDukeList.ユーザー番号1.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_211_登録後_ユーザー番号);

     //ID7_1_212_個別アカウント項目_ユーザー番号が表示されること
    	AdminDukeMod.ユーザー番号_項目.表示文言を検証("ユーザー番号");

        ReportCsv.chekedOK(CsvRecords.ID7_1_212_個別アカウント編集画面_ユーザー番号_項目);

     //ID7_1_213_個別アカウント項目_ログイン名（メールアドレス）が表示されること
    	AdminDukeMod.ログイン名_メールアドレス_項目.表示文言を検証("ログイン名(メールアドレス)");

        ReportCsv.chekedOK(CsvRecords.ID7_1_213_個別アカウント編集画面_ログイン名_項目);

     //ID7_1_214_個別アカウント項目_ニックネームが表示されること
    	AdminDukeMod.ニックネーム_項目.表示文言を検証("ニックネーム");

        ReportCsv.chekedOK(CsvRecords.ID7_1_214_個別アカウント編集画面_ニックネーム_項目);

     //ID7_1_215_個別アカウント項目_ファイル保管日数が表示されること
    	AdminDukeMod.ファイル保管日数_項目.表示文言を検証("ファイル保管日数");

        ReportCsv.chekedOK(CsvRecords.ID7_1_215_個別アカウント編集画面_ファイル保管日数_項目);

     //ID7_1_216_個別アカウント項目_店舗にあるマルチコピー機でのログイン方法が表示されること
    	AdminDukeMod.店舗にあるマルチコピー機でのログイン方法_項目.表示文言を検証("店舗にあるマルチコピー機でのログイン方法");

        ReportCsv.chekedOK(CsvRecords.ID7_1_216_個別アカウント編集画面_ログイン方法_項目);

     //ID7_1_217_個別アカウント項目_後課金_コピー機画面カスタマイズ設定が表示されること
    	AdminDukeMod.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_217_個別アカウント編集画面_後課金_コピー機画面カスタマイズ設定_項目);

     //ID7_1_218_個別アカウント項目_パスワード有効期限設定が表示されること
    	AdminDukeMod.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_218_個別アカウント編集画面_パスワード有効期限設定);

     //ID7_1_219_個別アカウント項目_パスワードが非表示であること
    	//AdminDukeMod.パスワード_項目.表示文言を検証("");

        //ReportCsv.chekedOK(CsvRecords.ID7_1_219_個別アカウント編集画面_パスワード_項目);

     //ID7_1_220_アカウント作成時に指定したユーザー番号が表示されていること
    	AdminDukeMod.ユーザー番号.表示文言を検証(")A10000001");

        ReportCsv.chekedOK(CsvRecords.ID7_1_220_個別アカウント編集画面_ユーザー番号);

     //ID7_1_221_ユーザー番号が編集不可であること
    	AdminDukeMod.ユーザー番号.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_221_個別アカウント編集画面_ユーザー番号);

     //ID7_1_222_WebUIログイン後画面に指定したユーザー番号が反映されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_222_WebUI_ユーザー番号);

     //ID7_1_223_[この設定で変更]にて、法人編集可能なこと
        AdminDukeMod.ログイン名_メールアドレス.テキストを上書き("cpiautouser1@test.tes");
        AdminDukeMod.この設定で変更する.スクロール();
        AdminDukeMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

        ReportCsv.chekedOK(CsvRecords.ID7_1_223_個別アカウント編集画面_メールアドレス);

     //ID7_1_224_個別アカウント一覧にログイン名(メールアドレス)が表示されていること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ログイン名編集.表示文言を検証("cpiautouser1@test.test");

        ReportCsv.chekedOK(CsvRecords.ID7_1_224_個別アカウント一覧画面_メールアドレス);

     //ID7_1_225_WebUIで変更したログイン名(メールアドレス）にて、ログインできること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_225_WebUI_メールアドレス);

        AdminDukeList.ユーザー番号1.スクロール(); //元の値に戻す処理
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ログイン名_メールアドレス.表示文言を検証("autouser1@test.test");
        AdminDukeMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

     //ID7_1_226_アカウント作成時に指定したニックネームが表示されていること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ニックネーム.表示文言を検証("自動個別アカウント");

        ReportCsv.chekedOK(CsvRecords.ID7_1_226_個別アカウント編集画面_ニックネーム);

      //ID7_1_227_ニックネームが編集不可であること
        AdminDukeMod.ニックネーム.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_227_個別アカウント編集画面_ニックネーム);

     //ID7_1_228_WebUIログイン後画面に指定したニックネームが反映されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_228_WebUI_ニックネーム);

     //ID7_1_229_[この設定で変更]にて、法人編集可能なこと
        //AdminDukeList.ユーザー番号1.スクロール();
        //AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ファイル保管日数.テキストを上書き("9");
        AdminDukeMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);

        ReportCsv.chekedOK(CsvRecords.ID7_1_229_個別アカウント編集画面_ファイル保管日数);

     //ID7_1_230_ファイル保管日数内のファイルが削除されないこと
        //ReportCsv.chekedOK(CsvRecords.ID7_1_230_WebUI_ファイル保管日数_期限内);

     //ID7_1_231_ファイル保管日数経過でファイルが削除されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_231_WebUI_ファイル保管日数_期限経過);

     //ID7_1_232_設定変更が不可であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_232_個別アカウント編集画面_ログイン方法);

     //ID7_1_233_「ユーザー番号のみまたはログイン名とパスワードでログインする。」が表示されていること
        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.表示文言を検証("ユーザー番号のみまたはログイン名とパスワードでログインする。");

        ReportCsv.chekedOK(CsvRecords.ID7_1_233_個別アカウント編集画面_ログイン方法);

        AdminDukeMod.キャンセル.クリック();

     //ID7_1_234_「ユーザー番号のみでのログインを禁止し、常にログイン名とパスワードでログインする。」が表示されていること
        AdminDukeList.ユーザー番号2.スクロール();
        AdminDukeList.ユーザー番号2.クリック();

        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.表示文言を検証("ユーザー番号のみでのログインを禁止し、常にログイン名とパスワードでログインする。");

        ReportCsv.chekedOK(CsvRecords.ID7_1_234_個別アカウント編集画面_ログイン方法);

     //ID7_1_235_(appdb)prnsys_appkey_costmizeのappキーがリストに表示されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_235_個別アカウント編集画面_後課金_コピー機画面カスタマイズ設定);

     //ID7_1_236_パスワード有効期限が切れた場合(180日経過後)、パスワード変更画面が表示されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_236_WebUI_パスワード有効期限_期限切れ);

     //ID7_1_237_180日経過後、パスワード変更画面が表示されないこと
        //ReportCsv.chekedOK(CsvRecords.ID7_1_237_WebUI_パスワード有効期限_期限内);

     //ID7_1_238_パスワードの有効期限(180日間)を設定するのチェックボックスが有効であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_238_個別アカウント編集画面_パスワード有効期限);

        AdminDukeMod.パスワード有効期限設定.チェックボックス選択(false);
        AdminDukeMod.この設定で変更する.クリック();
        AdminDukeList.確認ダイアログのボタン押下(true);
        Thread.sleep(2000);


     //ID7_1_239_パスワードの有効期限(180日間)を設定するのチェックボックスが無効であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

        ReportCsv.chekedOK(CsvRecords.ID7_1_239_個別アカウント編集画面_パスワード有効期限);

    	close();
    }

}

