package sbc.uitesttool.selenide.pageparts;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class getProperty{

	// ------ 変数の宣言:グローバル変数の宣言と初期化 ------
	public String BASE_URL = "";
	public String 法人向けログイン画面_URL = "";
	public String 個別法人画面_URL = "";
	public String タブ_一般アカウント_URL = "";
	public String NWPSWebUI_URL  = "";
	public String 表示用プレフィックス = "";
	public String 表示用企業名 = "";
	public String 法人アカウント編集 = "";
	public String 法人アカウント追加 = "";
	public String 企業名 = "";
	public String ユーザー番号のプレフィックス = "";
	public String メールアドレス = "";
	public String パスワード = "";
	public String 契約期間 = "";
	public String 法人アカウントの最大登録数 = "";
	public String 法人種別 = "";
	public String ファイルロギング設定 = "";
	public String 後課金コピー機画面カスタマイズ設定 = "";
	public String 初回ログイン時パスワード強制変更 = "";
	public String アカウント設定禁止 = "";
	public String 外部クラウドサービスとの連携 = "";
	public String forBiz用法人 = "";
	public String パスワード有効期限設定 = "";
	public String forBizLite用法人 = "";
	public String 印刷料金設定 = "";
	public String ベンダー料金設定 = "";
	public String forbizコンテンツ用法人 = "";
	public String 一般アカウント = "";
	public String パスワード変更 = "";
	public String ユーザー番号 = "";
	public String 企業情報 = "";
	public String 管理者アカウント = "";
	public String 利用状況取得 = "";
	public String ファイル管理 = "";
	public String 共有ボックス = "";

	//ユーザー情報
	public String 法人_プレフィックス = "";
	public String 法人_企業名 = "";
	public String 法人_メールアドレス = "";
	public String 法人_契約期間 = "";
	public String 法人_最大登録数 = "";
	public String lite_プレフィックス = "";
	public String lite_企業名 = "";
	public String lite_メールアドレス = "";
	public String lite_契約期間 = "";
	public String lite_最大登録数 = "";
	public String contents_プレフィックス = "";
	public String contents_企業名 = "";
	public String contents_メールアドレス = "";
	public String contents_契約期間 = "";
	public String contents_最大登録数 = "";
	public String 法人編集_企業名 = "";
	public String 追加アカウント = "";
	public String 個別_ユーザー番号_記号 = "";
	public String 個別_ニックネーム_記号 = "";
	public String 個別_メールアドレス_記号 = "";
	public String 個別_ユーザー番号 = "";
	public String 個別_メールアドレス = "";
	public String 個別_ニックネーム = "";
	public String 個別_編集 = "";
	public String ログイン名 = "";
	public String ニックネーム = "";
	public String ファイル保管日数 = "";
	public String MFPログイン方法 = "";
	public String MFPユーザー番号禁止 = "";
	public String 個別アカウントの表示ページ = "";

	//共通
	public String ログインパスワード = "";
	public String 新規ユーザー追加CSV = "";
	public String ユーザー削除CSV = "";
	public String 初回パス変更ユーザー = "";
	public String 有効期限パス変更ユーザー = "";
	public String 変更用パスワード = "";

	//各種SelectBox用List
	public List<String> forbizApp = new ArrayList<String>();
	public List<String> liteApp = new ArrayList<String>();
	public List<String> contentsApp = new ArrayList<String>();
	public List<String> externalApp = new ArrayList<String>();




	public void settings() throws IOException {
		// ------■前処理:テスト用プロパティファイルの読み込み ------
		String strpass = "C:\\Users\\CPI-148\\Documents\\DeskTop\\02.AutomationTool\\TestSrc\\SelenideSettings\\Settings.properties";
		File f = new File(strpass); //変更不可
		InputStream istream = new FileInputStream(f);
		Properties properties = new Properties();
		properties.load(istream);

		// ------■前処理:プロパティファイルから設定値を取得
		//一般法人
		法人_プレフィックス = properties.getProperty("biz_userprefix");
		法人_企業名 =  properties.getProperty("biz_corpname");
		法人_メールアドレス =  properties.getProperty("biz_mailaddress");
		法人_契約期間 = properties.getProperty("biz_contractperiod");
		法人_最大登録数 = properties.getProperty("biz_maxregist");

		//Lite法人
		lite_プレフィックス = properties.getProperty("lite_userprefix");
		lite_企業名 =  properties.getProperty("lite_corpname");
		lite_メールアドレス =  properties.getProperty("lite_mailaddress");
		lite_最大登録数 = properties.getProperty("lite_maxregist");

		//コンテンツ法人
		contents_プレフィックス = properties.getProperty("contents_userprefix");
		contents_企業名 =  properties.getProperty("contents_corpname");
		contents_メールアドレス =  properties.getProperty("contents_mailaddress");
		contents_最大登録数 = properties.getProperty("contents_maxregist");

		//個別
		個別_ユーザー番号_記号 = properties.getProperty("individualkigou_usernumber");;
		個別_ニックネーム_記号 = properties.getProperty("individualkigou_nickname");
		個別_メールアドレス_記号 = properties.getProperty("individualkigou_mailaddress");
		個別_ユーザー番号 = properties.getProperty("individualadd_usernumber");
		個別_メールアドレス = properties.getProperty("individualadd_mailaddress");
		個別_ニックネーム = properties.getProperty("individualadd_nickname");
		個別_編集 = properties.getProperty("contents_userprefix");
		個別アカウントの表示ページ = properties.getProperty("individualselectpage");

		//法人編集
		法人編集_企業名 =  properties.getProperty("bizmod_corpname");

		//共通
		ログインパスワード = properties.getProperty("biz_password");
		新規ユーザー追加CSV = properties.getProperty("addnewuser");
		ユーザー削除CSV = properties.getProperty("deleateuser");
		初回パス変更ユーザー = properties.getProperty("firstpasschange");
		有効期限パス変更ユーザー = properties.getProperty("180passchange");
		変更用パスワード = properties.getProperty("changepass");

		//向き先設定
		BASE_URL = properties.getProperty("bizaccountlistURL");
		法人向けログイン画面_URL = properties.getProperty("bizaccountloginURL");
		個別法人画面_URL = properties.getProperty("bizindividualURL");
		タブ_一般アカウント_URL = properties.getProperty("tab_generalURL");
		NWPSWebUI_URL  =  properties.getProperty("NWPSWebUI_URL");

		//タイトル・項目確認
		表示用プレフィックス = properties.getProperty("dispUserPrefix");
		表示用企業名 = properties.getProperty("dispcorpname");
		法人アカウント編集 = properties.getProperty("KC_bizaccountmod");
		法人アカウント追加 = properties.getProperty("KC_bizaccountadd");
		企業名 = properties.getProperty("KC_corpname");
		ユーザー番号のプレフィックス = properties.getProperty("KC_titleuserprefix");
		メールアドレス = properties.getProperty("KC_mailaddress");
		パスワード = properties.getProperty("KC_password");
		契約期間 = properties.getProperty("KC_contractperiod");
		法人アカウントの最大登録数 = properties.getProperty("KC_maxregist");
		法人種別 = properties.getProperty("KC_forbizclass");
		ファイルロギング設定 = properties.getProperty("KC_filelogging");
		後課金コピー機画面カスタマイズ設定 = properties.getProperty("KC_customize");
		初回ログイン時パスワード強制変更 = properties.getProperty("KC_1stloginpasschange");
		アカウント設定禁止 = properties.getProperty("KC_prohibitionaccount");
		外部クラウドサービスとの連携 = properties.getProperty("KC_externalApp");
		forBiz用法人 = properties.getProperty("KC_bizclass");
		パスワード有効期限設定 = properties.getProperty("KC_pwexpiration");
		forBizLite用法人 = properties.getProperty("KC_liteclass");
		印刷料金設定 = properties.getProperty("KC_printfeesetting");
		ベンダー料金設定 = properties.getProperty("KC_venderfeesetting");
		forbizコンテンツ用法人 = properties.getProperty("KC_contentsclass");
		一般アカウント = properties.getProperty("KC_generalaccount");
		パスワード変更 = properties.getProperty("KC_changepassword");
		ユーザー番号 = properties.getProperty("KC_usernumber");
		企業情報 = properties.getProperty("KC_corpinfomation");
		管理者アカウント = properties.getProperty("KC_adminaccount");
		利用状況取得 = properties.getProperty("KC_getuserge");
		ファイル管理 = properties.getProperty("KC_filemanage");
		共有ボックス = properties.getProperty("KC_smbbox");
		追加アカウント = properties.getProperty("biz_addacount");
		ログイン名 = properties.getProperty("KC_indivimailaddress");
		ニックネーム = properties.getProperty("KC_indivinickname");
		ファイル保管日数 = properties.getProperty("KC_indivinickname");
		MFPログイン方法 = properties.getProperty("KC_howtoMFPlogin");
		MFPユーザー番号禁止 = properties.getProperty("KC_howtoMFPloginnotallow");

	}



}
