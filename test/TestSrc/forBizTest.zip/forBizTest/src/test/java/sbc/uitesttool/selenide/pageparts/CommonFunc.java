package sbc.uitesttool.selenide.pageparts;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CommonFunc{

  	/* ------------------- 			実行前DB処理実行コマンド		   ------------------------- */
    /* 作成日: 	2019/02																			 */
    /* 引数/返値：	なし												 						 */
    /* 動作：以下自動化テストで使用した法人アカウントをDB操作で削除する							 */
    /* note:<<C:\Users\CPI-148\Documents\DeskTop\02.AutomationTool\sql>>のSQLを					 */
    /* batchで実行しています。(Javaからttlを直接実行できなかったので)							 */
    /* ttlの格納場所を絶対相対パスで実行しているので、SQLの場所などを変更した場合は				 */
    /* "preparation_corplist.bat"の内容を変更してください。(Ansiで保存)							 */
    /*-------------------------------------------------------------------------------------------*/

	public void BatExec_Del4Biz () {
	        String cline = "cmd.exe /c start C:\\Users\\CPI-148\\Documents\\DeskTop\\02.AutomationTool\\TestSrc\\batchFiles\\preparation_corplist.bat";
	        try {
	            Runtime.getRuntime().exec(cline);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

  	/* ------------------- 			パスワードの有効期限切れSQL実行		   --------------------- */
    /* 作成日: 	2019/02																			 */
    /* 引数/返値：	なし												 						 */
    /* 動作：パスワードの有効期限切れSQLを自動で実行する										 */
    /*-------------------------------------------------------------------------------------------*/

	public void validatedDate() {
		//Calendarオブジェクトで本日の日付を取得する
	     Calendar todaydate = Calendar.getInstance();

	     //本日から180日前の日付を取得する
	     todaydate.add(Calendar.DATE, -180);

	     //フォーマットを生成する
	     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	     //結果をstring型にキャストする
	     String strsdf = sdf.format(todaydate.getTime());

	     //結果をテキストファイルに出力する
		   try{
			   File fileadmin = new File("C:\\Users\\CPI-148\\Documents\\DeskTop\\02.AutomationTool\\TestSrc\\forBizTest\\src\\test\\resources\\180day_admin.txt");
			   File fileuser = new File("C:\\Users\\CPI-148\\Documents\\DeskTop\\02.AutomationTool\\TestSrc\\forBizTest\\src\\test\\resources\\180day_user.txt");
			   FileWriter fwriteradmin = new FileWriter(fileadmin);
			   FileWriter fwriteruser = new FileWriter(fileuser);

			   //データをSQLに成型する
			   String SQL180dayadmin = "update prnsys_admin set updatepwdate = '" + strsdf + "' where groupcode = ']X1';";

			   String SQL180dayuser1 = "update prnsys_user set updatepwdate = '" + strsdf + "' where loginid = ']X11111111';";
			   String SQL180dayuser2 = "update prnsys_user set updatepwdate = '" + strsdf + "' where loginid = ']X11111112';";

			   //成型したデータをテキストファイルに書き込む
			   fwriteradmin.write(SQL180dayadmin);
			   fwriteruser.write(SQL180dayuser1);
			   fwriteruser.write(SQL180dayuser2);

			   //ファイルを閉じる
			   fwriteradmin.close();
			   fwriteruser.close();

			 }catch(IOException e){
			   System.out.println(e);
			 }

		   //SQL文を読み込みデータベースに反映する
	        String cline = "cmd.exe /c start C:\\Users\\CPI-148\\Documents\\DeskTop\\02.AutomationTool\\TestSrc\\batchFiles\\validateddate_180.bat";
	        try {
	            Runtime.getRuntime().exec(cline);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }


	}

}
