package sbc.uitesttool.selenide.pageparts;

import org.sahagin.runlib.external.PageDoc;

//TODO:enumの処理共通化

@PageDoc("法人管理者ログイン共通関数")

public class CommonFunc_CorpAdminLogin {

	   /* ---------------------Corptest_AdminLogin 共通使用関数 ----------------------- */

	  	/* ■ログイン関数------------------------------------------------ */
	    /* 作成日: 	2018/11/15											 */
	    /* 引数:	ログイン名（String lname）,パスワード（String lpass）*/
	    /* 返値：	なし												 */
	    /* 動作：システム管理者ログイン画面でのログイン			 	 	 */
	    /*---------------------------------------------------------------*/
	    public void ログイン(String lname, String lpass) {
			AdminCorpLogin.ログイン名.テキストを上書き(lname);
			AdminCorpLogin.ログインパスワード.テキストを上書き(lpass);
			AdminCorpLogin.ログインボタン.クリック();

	    }

}
