package sbc.uitesttool.selenide;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.junit.TextReport;

import sbc.uitesttool.selenide.pageparts.AdminCorpLogin;
import sbc.uitesttool.selenide.pageparts.SelenideTestWatcher;
import sbc.uitesttool.selenide.report.ReportCsv_Login;
import sbc.uitesttool.selenide.report.records.CsvRecords_Login;

//TODO:enumの処理共通化

@PageDoc("法人管理者ログイン")
public class ID7_2_Corptest_AdminLogin {
    // TODO:後で共通化する
    private static final String 法人向けログイン画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/login.html";
    private static final String タブ_管理者アカウント_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/adminaccount.html";
    private static final String タブ_一般アカウント_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/accountmng.html";
    private static final String タブ_利用履歴_URL ="https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/usage.html";
    private static final String タブ_ファイル検索_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/filemng.html";



   	/* ------------------- テスト実行失敗時のエビデンス取得------------------------- */
    /* 作成日: 	2018/10																 */
    /* 引数/返値：	なし												 			 */
    /* 動作：テスト失敗時のモニタログ/失敗時のキャプチャ取得 						 */
    /*-------------------------------------------------------------------------------*/

    /* debug code Start---->*/
    //実行失敗時に左側のコンソールに失敗した要素のID取得時間が出る
    @Rule
    public TestRule report = new TextReport();

    //実行失敗時にスクリーンキャプチャを取得する
    @Rule
    public SelenideTestWatcher watcher = new SelenideTestWatcher();

   /* <-----debug code End>*/


    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");

	//画面遷移が多いのでTimeout時間を延長する（デフォルト4000）
	Configuration.timeout = 7000;

    }

    @AfterClass
    public static void afterClass() {
    	ReportCsv_Login.outputCsv();
    }

    @Test
    public void 法人アカウントログインでの基本機能テスト() throws InterruptedException, IOException {

	//ID7_2_1_forbiz用アカウントログイン
		open(法人向けログイン画面_URL);
		AdminCorpLogin.ログイン名.テキストを上書き("bokekya381@ruru.be");
		AdminCorpLogin.ログインパスワード.テキストを上書き("cpi12345");
		AdminCorpLogin.ログインボタン.クリック();

		//■ログイン確認: サブタイトル"企業情報"が表示されていること
		AdminCorpLogin.企業情報.表示文言を検証("企業情報");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_1_forbiz用アカウントログイン);


	//ID7_2_2_利用規約ダウンロード　Todo:PCの画面をキャプチャできる？
		AdminCorpLogin.利用規約ダウンロード.クリック();
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_2_利用規約ダウンロード);

	//ID7_2_3_NWPSロゴ検証_forbiz
		AdminCorpLogin.NWPSロゴforbiz.画像のソースを検証("/forBiz/images/top_rogo.png");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_3_NWPSロゴ検証_forbiz);

	//ID7_2_4_ログインパスワードの変更
		AdminCorpLogin.現在のパスワード.テキストを上書き("cpi12345");
		AdminCorpLogin.新規パスワード.テキストを上書き("cpinfo00");
		AdminCorpLogin.新規パスワード確認.テキストを上書き("cpinfo00");
		AdminCorpLogin.変更ボタン.クリック();

		AdminCorpLogin.確認ダイアログのボタン押下(true);
		AdminCorpLogin.パスワード変更メッセージ.表示文言を検証("※パスワードを変更しました。");
		AdminCorpLogin.ログアウト.クリック();
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_4_ログインパスワードの変更);

	//ID7_2_5_パスワード変更後の再ログイン
		AdminCorpLogin.ログイン名.テキストを上書き("bokekya381@ruru.be");
		AdminCorpLogin.ログインパスワード.テキストを上書き("cpinfo00");
		AdminCorpLogin.ログインボタン.クリック();

		//■ログイン確認: サブタイトル"企業情報"が表示されていること
		AdminCorpLogin.企業情報.表示文言を検証("企業情報");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_5_パスワード変更後の再ログイン);

		//■後処理：次回ログイン時のために元のパスワードに変更する
		AdminCorpLogin.現在のパスワード.テキストを上書き("cpinfo00");
		AdminCorpLogin.新規パスワード.テキストを上書き("cpi12345");
		AdminCorpLogin.新規パスワード確認.テキストを上書き("cpi12345");
		AdminCorpLogin.変更ボタン.クリック();

		AdminCorpLogin.確認ダイアログのボタン押下(true);
		AdminCorpLogin.パスワード変更メッセージ.表示文言を検証("※パスワードを変更しました。");
		AdminCorpLogin.ログアウト.クリック();

	//ID7_2_6_管理者アカウントの追加
		AdminCorpLogin.ログイン名.テキストを上書き("bokekya381@ruru.be");
		AdminCorpLogin.ログインパスワード.テキストを上書き("cpi12345");
		AdminCorpLogin.ログインボタン.クリック();

		//■ログイン確認: サブタイトル"企業情報"が表示されていること
		AdminCorpLogin.企業情報.表示文言を検証("企業情報");

		//■[管理者アカウント]画面に遷移: サブタイトル"管理者アカウント"が表示されていること
		open(タブ_管理者アカウント_URL);
		AdminCorpLogin.管理者アカウント.表示文言を検証("管理者アカウント");
		AdminCorpLogin.管理者アカウントを追加する.クリック();

		AdminCorpLogin.管理者アカウント追加_メール.テキストを上書き("foraba@macr2.com");
		AdminCorpLogin.管理者アカウント追加_パスワード.テキストを上書き("cpi12345");
		AdminCorpLogin.管理者アカウント追加_この設定を登録する.クリック();

		AdminCorpLogin.管理者アカウント追加メッセージ.表示文言を検証("※管理者アカウントを追加しました。");
		AdminCorpLogin.追加アカウント.表示文言を検証("foraba@macr2.com");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_6_管理者アカウントの追加);

	//ID7_2_7_管理者アカウントの削除
		AdminCorpLogin.アカウント削除.クリック();
		AdminCorpLogin.確認ダイアログのボタン押下(true);
		AdminCorpLogin.追加アカウント.表示文言が存在しないことを検証();
		AdminCorpLogin.管理者アカウント削除メッセージ.表示文言を検証("※管理者アカウントを削除しました。");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_7_管理者アカウントの追加);

	//ID7_2_8_CSVから新規アカウントが登録できること
		open(タブ_一般アカウント_URL);
		//■[一般アカウント]画面に遷移: サブタイトル"一般アカウント"が表示されていること
		AdminCorpLogin.一般アカウント.表示文言を検証("一般アカウント");
		//比較用CSVを出力する
		AdminCorpLogin.CSVで出力.クリック();
		AdminCorpLogin.選択.アップロードするファイルを選択する("UserList_new.csv");
		AdminCorpLogin.CSVで入力.クリック();
		Thread.sleep(5000);
		AdminCorpLogin.CSV_戻る.クリック();
		AdminCorpLogin.CSVで出力.クリック();
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_8_CSVからの新規アカウント登録);

	//ID7_2_9_CSVから既存アカウントが変更できること
	//ID7_2_10_CSVから既存アカウントが削除できること
		open(タブ_一般アカウント_URL);
		//■[一般アカウント]画面に遷移: サブタイトル"一般アカウント"が表示されていること
		AdminCorpLogin.一般アカウント.表示文言を検証("一般アカウント");
		AdminCorpLogin.選択.アップロードするファイルを選択する("UserList_moddel.csv");
		AdminCorpLogin.CSVで入力.クリック();
		Thread.sleep(5000);
		AdminCorpLogin.CSV_戻る.クリック();

		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_9_CSVからの既存アカウント変更);
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_10_CSVからの既存アカウント削除);

	//ID7_2_11_登録されているアカウントの情報をCSVでダウンロードできること　Todo:PCの画面をキャプチャできる？csvを比較してチェックリスト作れる？＆自動的にuserlist.csvを消せる？
		AdminCorpLogin.CSVで出力.クリック();
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_11_アカウントの情報CSVダウンロード);

		//■後処理：次回テストのために固定ユーザ以外を削除する
		AdminCorpLogin.選択.アップロードするファイルを選択する("UserList_del.csv");


	//ID7_2_12_対象日で利用履歴を抽出することができること（調査中：Skip）
		//現状は対象日付を入力できない。
/*
		//日付の取得
		Calendar cal = Calendar.getInstance();
		int iyear = cal.get(Calendar.YEAR);
		int imonth =  cal.get(Calendar.MONTH);
		int idate = cal.get(Calendar.DATE);

		String syear = String.valueOf(iyear);
		String smonth = String.valueOf(imonth+1);
		String sdate = String.valueOf(idate);
		String firstdate =  syear + "/" +  smonth + "/" + "1";
		String enddate = syear + "/" +  smonth + "/" + sdate;

		open(タブ_利用履歴_URL);
		AdminCorpLogin.利用期間開始月入力.カレンダーの日付を入力する(firstdate);
		AdminCorpLogin.利用期間終了月入力.カレンダーの日付を入力する(enddate);
*/
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_12_利用履歴を対象日で絞り込む);


	//ID7_2_13_ユーザー番号で利用履歴を抽出することができること

		//open(タブ_利用履歴_URL);
		//■[利用履歴]画面に遷移: サブタイトル"利用履歴"(ソース内は"利用状況取得"になっている)が表示されていること
		open(タブ_利用履歴_URL);
		AdminCorpLogin.利用履歴.表示文言を検証("利用状況取得");
		AdminCorpLogin.RBユーザー番号.クリック();
		AdminCorpLogin.履歴検索ワード.テキストを上書き("(121111111");
		Thread.sleep(5000);
		AdminCorpLogin.利用履歴CSV.クリック();

		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_13_利用履歴をユーザー番号で絞り込む);

	//ID7_2_14_メールアドレスで利用履歴を抽出することができること
		AdminCorpLogin.利用履歴.表示文言を検証("利用状況取得");
		AdminCorpLogin.RBメールアドレス.クリック();
		AdminCorpLogin.履歴検索ワード.テキストを上書き("history2@test.test");
		Thread.sleep(5000);
		AdminCorpLogin.利用履歴CSV.クリック();

		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_14_利用履歴をメールアドレスで絞り込む);
		Thread.sleep(5000);

	//ID7_2_15_登録期間でファイル検索ができること(調査中：Skip）
		//現状は対象日付を入力できない。
		open(タブ_ファイル検索_URL);
		AdminCorpLogin.ファイル検索.画像のaltを検証("ファイル検索");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_15_ファイルを登録期間で検索する);

	//ID7_2_16_ユーザー番号で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル検索ワード.テキストを上書き("(121111111");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History1ファイル名.表示文言を検証("test3.pdf");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_16_ファイルをユーザー番号で検索する);

	//ID7_2_17_ニックネームで検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル検索ワード.テキストを上書き("固定ユーザー2");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History2ファイル名.表示文言を検証("test5.jpeg");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_17_ファイルをニックネームで検索する);

	//ID7_2_18_メールアドレスで検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル検索ワード.テキストを上書き("history3@test.test");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History3ファイル名.表示文言を検証("test1.docx");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_18_ファイルをメールアドレスで検索する);

		//■後処理：アドレス検索テキストボックスをクリアする
		AdminCorpLogin.ファイル検索ワード.テキストをクリア();

	//ID7_2_19_ファイル名で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル名検索.テキストを上書き("test3.pdf");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History1ファイル名.表示文言を検証("test3.pdf");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_19_ファイルをファイル名で検索する);

	//ID7_2_20_登録名で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル名検索.テキストを上書き("test1.docx");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History3ファイル名.表示文言を検証("test1.docx");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_20_ファイルを登録名で検索する);

		//■後処理：アドレス検索テキストボックスをクリアする
		AdminCorpLogin.ファイル名検索.テキストをクリア();

	//ID7_2_21_登録先を「全て」で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル名検索.Selectボックス選択("全て");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History1ファイル名.表示文言を検証("test3.pdf");
		AdminCorpLogin.History2ファイル名.表示文言を検証("test5.jpeg");
		AdminCorpLogin.History3ファイル名.表示文言を検証("test1.docx");
		AdminCorpLogin.共有ファイル名.表示文言を検証("test4.jpeg");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_21_ファイルを登録先_全て_で検索する);

	//ID7_2_22/ID7_2_23_登録先を「マイボックス」で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル名検索.Selectボックス選択("マイボックス");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History1ファイル名.表示文言を検証("test3.pdf");
		AdminCorpLogin.History2ファイル名.表示文言を検証("test5.jpeg");
		AdminCorpLogin.History3ファイル名.表示文言を検証("test1.docx");
		AdminCorpLogin.共有ファイル名.表示文言が存在しないことを検証();
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_22_ファイルを登録先_マイボックス_で検索する);
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_23_ファイルを登録先_マイボックス_で検索する);

	//ID7_2_24/ID7_2_25_登録先を「SMB」(共有フォルダ)で検索した結果がファイルリストに表示されること
		AdminCorpLogin.ファイル名検索.Selectボックス選択("マイボックス");
		Thread.sleep(5000);
		AdminCorpLogin.検索する.クリック();
		Thread.sleep(3000);
		AdminCorpLogin.History1ファイル名.表示文言が存在しないことを検証();
		AdminCorpLogin.History2ファイル名.表示文言が存在しないことを検証();
		AdminCorpLogin.History3ファイル名.表示文言が存在しないことを検証();
		AdminCorpLogin.共有ファイル名.表示文言を検証("test4.jpeg");
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_24_ファイルを登録先_共有フォルダ_で検索する);
		ReportCsv_Login.chekedOK(CsvRecords_Login.ID7_2_24_ファイルを登録先_共有フォルダ_で検索する);




	    close();
	    }

	}