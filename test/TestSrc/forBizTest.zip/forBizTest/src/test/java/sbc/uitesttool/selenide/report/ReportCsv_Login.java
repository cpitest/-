package sbc.uitesttool.selenide.report;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import sbc.uitesttool.selenide.report.records.CsvRecords_Login;

/**
 * 結果CSV出力処理を行うクラス
 *
 */
public class ReportCsv_Login {
    private static final String SEPARATOR = FileSystems.getDefault().getSeparator();
    private static final String CSV_OUTPUT_PATH = "." + SEPARATOR + "report" + SEPARATOR;

    private static Map<CsvRecords_Login, ReportStatus> reportByResult = new HashMap<>();

    /**
     * 対象テスト結果にOKをつける
     *
     * @param record
     */
    public static void chekedOK(CsvRecords_Login record) {
	reportByResult.put(record, ReportStatus.OK);
    }

    /**
     * 対象テスト結果にNGをつける
     *
     * @param testId
     */
    public static void chekedNG(CsvRecords_Login record) {
	reportByResult.put(record, ReportStatus.NG);
    }

    /**
     * 結果CSVを出力する
     */
    public static void outputCsv() {
	PrintWriter pw = null;
	try {
	    Path pathByDirectory = Paths.get(CSV_OUTPUT_PATH);
	    if (!Files.exists(pathByDirectory)) {
		Files.createDirectories(pathByDirectory);
	    }

	    Path pathByFile = pathByDirectory.resolve("report_login.csv");
	    if (Files.exists(pathByFile)) {
		Files.delete(pathByFile);
	    }

	    pw = new PrintWriter(new BufferedWriter(
		    new OutputStreamWriter(new FileOutputStream(pathByFile.toFile(), true), "Shift-JIS")));

	    for (CsvRecords_Login CsvRecords_Login : CsvRecords_Login.values()) {
		StringBuilder sb = new StringBuilder();
		sb.append(CsvRecords_Login.getId());
		sb.append(",");
		sb.append(CsvRecords_Login.getTestDetail());
		sb.append(",");
		sb.append(getStatus(CsvRecords_Login));

		System.out.println(sb.toString());
		pw.println(sb.toString());
	    }
	} catch (Exception e) {
	    System.out.println("CSV出力に失敗\r\n" + e.getMessage() + "\r\n" + e.getStackTrace());
	} finally {
	    if (pw != null) {
		pw.close();
	    }
	}
    }

    /**
     * テスト結果を返す
     *
     * @param CsvRecords_Login
     *            対象のテスト項目
     * @return
     */
    private static String getStatus(CsvRecords_Login CsvRecords_Login) {
	ReportStatus status = reportByResult.get(CsvRecords_Login);
	if (status != null) {
	    return status.getValue();
	}

	return CsvRecords_Login.getDefaultStatus().getValue();
    }
}
