package sbc.uitesttool.selenide.report.records;

import sbc.uitesttool.selenide.report.ReportStatus;

/**
 * CSVに出力する行をまとめた列挙体
 *
 */
public enum CsvRecords_Login {
	/** forBiz用法人でログインができること */
	ID7_2_1_forbiz用アカウントログイン("7_2_1", "forBiz用法人でログインができること", true),  //
	ID7_2_2_利用規約ダウンロード("7_2_2", "利用規約のダウンロードが可能であること", true),  //
	ID7_2_3_NWPSロゴ検証_forbiz("7_2_3", "NWPSロゴ「ネットワークプリントサービスforbiz」が表示されていること", true),  //
	ID7_2_4_ログインパスワードの変更("7_2_4", "パスワード変更が完了すること", true),  //
	ID7_2_5_パスワード変更後の再ログイン("7_2_5", "変更したパスワードで再ログインできること", true),  //
	ID7_2_6_管理者アカウントの追加("7_2_6","管理者アカウントが追加されること", true), //
	ID7_2_7_管理者アカウントの追加("7_2_7","管理者アカウントが削除されること", true), //
	ID7_2_8_CSVからの新規アカウント登録("7_2_8","CSVからの新規アカウント登録", false), //
	ID7_2_9_CSVからの既存アカウント変更("7_2_9","CSVからの既存アカウント変更", false), //
	ID7_2_10_CSVからの既存アカウント削除("7_2_10","CSVからの既存アカウント削除", false), //
	ID7_2_11_アカウントの情報CSVダウンロード("7_2_11","アカウントの情報CSVダウンロード", true), //
	ID7_2_12_利用履歴を対象日で絞り込む("7_2_12","利用履歴を対象日で絞り込む", false), //
	ID7_2_13_利用履歴をユーザー番号で絞り込む("7_2_13","利用履歴をユーザー番号で絞り込む", true), //
	ID7_2_14_利用履歴をメールアドレスで絞り込む("7_2_14","利用履歴をメールアドレスで絞り込む", true), //
	ID7_2_15_ファイルを登録期間で検索する("ID7_2_15","ファイルを登録期間で検索する", false),//
	ID7_2_16_ファイルをユーザー番号で検索する("ID7_2_16","ファイルをユーザー番号で検索する", true),//
	ID7_2_17_ファイルをニックネームで検索する("ID7_2_17","ファイルをニックネームで検索する", true),//
	ID7_2_18_ファイルをメールアドレスで検索する("ID7_2_18","ファイルをメールアドレスで検索する", true),//
	ID7_2_19_ファイルをファイル名で検索する("ID7_2_19","ファイルをファイル名で検索する", true),//
	ID7_2_20_ファイルを登録名で検索する("ID7_2_20","ファイルを登録名で検索する", true),//
	ID7_2_21_ファイルを登録先_全て_で検索する("ID7_2_21","ファイルを登録先「全て」で検索する", true),
	ID7_2_22_ファイルを登録先_マイボックス_で検索する("ID7_2_22","ファイルを登録先「マイボックス」で検索(マイボックスのファイルが表示される)", true),//
	ID7_2_23_ファイルを登録先_マイボックス_で検索する("ID7_2_23","ファイルを登録先「マイボックス」で検索(共有フォルダのファイルが表示されない)", true),//
	ID7_2_24_ファイルを登録先_共有フォルダ_で検索する("ID7_2_24","ファイルを登録先「共有フォルダ」で検索(共有フォルダのファイルが表示される)", true),//
	ID7_2_25_ファイルを登録先_共有フォルダ_で検索する("ID7_2_25","ファイルを登録先「共有フォルダ」で検索(マイボックスのファイルが表示されない)", true),//






    ;

    private String id; // 出図シートのid
    private String testDetail; // 出図シートの確認内容
    private boolean testAble; // selenideでテスト可能な場合はtrue, selenideでテスト不可能な場合はfalse

    public String getId() {
	return id;
    }

    public boolean isTestAble() {
	return testAble;
    }

    public String getTestDetail() {
	return testDetail;
    }

    public ReportStatus getDefaultStatus() {
	if (testAble) {
	    return ReportStatus.NG;
	}

	return ReportStatus.SKIP;
    }

    private CsvRecords_Login(String id, String testDetail, boolean testAble) {
	this.id = id;
	this.testDetail = testDetail;
	this.testAble = testAble;
    }
}
