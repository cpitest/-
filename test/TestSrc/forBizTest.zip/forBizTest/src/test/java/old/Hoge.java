package old;

import static com.codeborne.selenide.Selenide.*;

import org.junit.BeforeClass;
import org.openqa.selenium.remote.BrowserType;

import sbc.uitesttool.selenide.pageparts.BizLogin;
import sbc.uitesttool.selenide.report.ReportCsv;
import sbc.uitesttool.selenide.report.records.CsvRecords;

import com.codeborne.selenide.Configuration;

public class Hoge {
    // TODO:後で共通化する
    //private static final String BASE_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/admin/app";
    private static final String 法人向けログイン画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/login.html";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

	public void テスト() {
    	//ID7_1_170_追加した管理者アカウントで管理者ページにログインできること
    	open(法人向けログイン画面_URL);

    	BizLogin.ログイン名.テキストを上書き("morinaga2@test.test");
    	BizLogin.パスワード.テキストを上書き("cpi12345");
    	BizLogin.ログインボタン.クリック();

    	ReportCsv.chekedOK(CsvRecords.ID7_1_100_法人アカウント一覧画面_企業名);
    	
    	
	}
}
