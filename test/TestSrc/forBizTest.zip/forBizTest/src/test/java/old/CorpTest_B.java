package old;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import sbc.uitesttool.selenide.pageparts.BizLogin;
import sbc.uitesttool.selenide.report.ReportCsv;
import sbc.uitesttool.selenide.report.ScreenShot;
import sbc.uitesttool.selenide.report.records.CsvRecords;

import com.codeborne.selenide.Configuration;

//TODO:enumの処理共通化

@PageDoc("法人アカウント.法人アカウント一覧")
public class CorpTest_B {
    // TODO:後で共通化する
    private static final String BASE_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/admin/app";
    private static final String 法人向けログイン画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/login.html";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

    @AfterClass
    public static void afterClass() {
	ReportCsv.outputCsv();
    }

    @Test
    public void 法人向け管理者ログイン_エラー() throws InterruptedException, IOException {
    //ID7_1_170_追加した管理者アカウントで管理者ページにログインできること
    	open(法人向けログイン画面_URL);

    	BizLogin.ログイン名.テキストを上書き("at1no1@test.test");
    	BizLogin.パスワード.テキストを上書き("cpi12345");
    	BizLogin.ログインボタン.クリック();

    	ScreenShot.takesScreenshot("ID7_1_170_追加した管理者アカウントで管理者ページにログインできること.png");

    	ReportCsv.chekedOK(CsvRecords.ID7_1_170_法人管理アカウント追加_管理者ログイン);

	close();
    }

}
