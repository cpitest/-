package old;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import sbc.uitesttool.selenide.report.ReportCsv;
import testttttttt.ID7_1_2_CorpTest_A_old;

import com.codeborne.selenide.Configuration;

//TODO:enumの処理共通化

@PageDoc("法人アカウント.法人アカウント一覧")
public class CopyOfCorpListTest {
    // TODO:後で共通化する
    private static final String BASE_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/admin/app";
    private static final String 法人向けログイン画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/login.html";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

    @AfterClass
    public static void afterClass() {
	ReportCsv.outputCsv();
    }

    @Test
    public void 法人アカウント一覧のテスト_一覧表示() throws InterruptedException, IOException {

    	ID7_1_2_CorpTest_A_old corptest_a = new ID7_1_2_CorpTest_A_old();
		corptest_a.法人向け管理者ログイン();

		CorpTest_B corptest_b = new CorpTest_B();
		corptest_b.法人向け管理者ログイン_エラー();


	close();
    }

}
