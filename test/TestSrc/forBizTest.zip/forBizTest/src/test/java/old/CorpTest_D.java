package old;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import sbc.uitesttool.selenide.pageparts.AdminDukeList;
import sbc.uitesttool.selenide.pageparts.AdminDukeMod;
import sbc.uitesttool.selenide.report.ReportCsv;
import sbc.uitesttool.selenide.report.records.CsvRecords;

import com.codeborne.selenide.Configuration;

//TODO:enumの処理共通化

@PageDoc("法人アカウント.法人アカウント一覧")
public class CorpTest_D {
    // TODO:後で共通化する
    //private static final String BASE_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/admin/app";
    private static final String 個別法人画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/adminbusinessuserlist.html";
    //private static final String 法人向けログイン画面_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/view/main/login.html";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

    @AfterClass
    public static void afterClass() {
	ReportCsv.outputCsv();
    }

    @Test
    public void 法人向け管理者ログイン() throws InterruptedException, IOException {
        //ID7_1_174_個別アカウント一覧にユーザー番号が表示されていること
    	open(個別法人画面_URL);

      //ID7_1_208_作成した個別アカウントの[ユーザー番号]が一覧に表示されていること
        AdminDukeList.ページ選択.Selectボックス選択("2");
    	AdminDukeList.ユーザー番号1.表示文言を検証(")A10000001");

        	ReportCsv.chekedOK(CsvRecords.ID7_1_208_登録後_ユーザー番号表示);

     //ID7_1_209_作成した個別アカウントの[ログイン名（メールアドレス）]が一覧に表示されること
    	AdminDukeList.ログイン名1.表示文言を検証("autouser1@test.test");

        ReportCsv.chekedOK(CsvRecords.ID7_1_209_登録後_ログイン名);

     //ID7_1_210_作成した個別アカウントの[ニックネーム]が選択できること
    	AdminDukeList.ニックネーム1.スクロール();
    	AdminDukeList.ニックネーム1.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_210_登録後_ニックネーム);

     //ID7_1_211_作成した個別アカウントの[ユーザー番号]が選択できること
    	AdminDukeList.ユーザー番号1.スクロール();
    	AdminDukeList.ユーザー番号1.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_211_登録後_ユーザー番号);

     //ID7_1_212_個別アカウント項目_ユーザー番号が表示されること
    	AdminDukeMod.ユーザー番号_項目.表示文言を検証("ユーザー番号");

        ReportCsv.chekedOK(CsvRecords.ID7_1_212_個別アカウント編集画面_ユーザー番号_項目);

     //ID7_1_213_個別アカウント項目_ログイン名（メールアドレス）が表示されること
    	AdminDukeMod.ログイン名_メールアドレス_項目.表示文言を検証("ログイン名(メールアドレス)");

        ReportCsv.chekedOK(CsvRecords.ID7_1_213_個別アカウント編集画面_ログイン名_項目);

     //ID7_1_214_個別アカウント項目_ニックネームが表示されること
    	AdminDukeMod.ニックネーム_項目.表示文言を検証("ニックネーム");

        ReportCsv.chekedOK(CsvRecords.ID7_1_214_個別アカウント編集画面_ニックネーム_項目);

     //ID7_1_215_個別アカウント項目_ファイル保管日数が表示されること
    	AdminDukeMod.ファイル保管日数_項目.表示文言を検証("ファイル保管日数");

        ReportCsv.chekedOK(CsvRecords.ID7_1_215_個別アカウント編集画面_ファイル保管日数_項目);

     //ID7_1_216_個別アカウント項目_店舗にあるマルチコピー機でのログイン方法が表示されること
    	AdminDukeMod.店舗にあるマルチコピー機でのログイン方法_項目.表示文言を検証("店舗にあるマルチコピー機でのログイン方法");

        ReportCsv.chekedOK(CsvRecords.ID7_1_216_個別アカウント編集画面_ログイン方法_項目);

     //ID7_1_217_個別アカウント項目_後課金_コピー機画面カスタマイズ設定が表示されること
    	AdminDukeMod.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_217_個別アカウント編集画面_後課金_コピー機画面カスタマイズ設定_項目);

     //ID7_1_218_個別アカウント項目_パスワード有効期限設定が表示されること
    	AdminDukeMod.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

        ReportCsv.chekedOK(CsvRecords.ID7_1_218_個別アカウント編集画面_パスワード有効期限設定);

     //ID7_1_219_個別アカウント項目_パスワードが非表示であること
    	//AdminDukeMod.パスワード_項目.表示文言を検証("");

        //ReportCsv.chekedOK(CsvRecords.ID7_1_219_個別アカウント編集画面_パスワード_項目);

     //ID7_1_220_アカウント作成時に指定したユーザー番号が表示されていること
    	AdminDukeMod.ユーザー番号.表示文言を検証(")A10000001");

        ReportCsv.chekedOK(CsvRecords.ID7_1_220_個別アカウント編集画面_ユーザー番号);

     //ID7_1_221_ユーザー番号が編集不可であること
    	AdminDukeMod.ユーザー番号.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_221_個別アカウント編集画面_ユーザー番号);

     //ID7_1_222_WebUIログイン後画面に指定したユーザー番号が反映されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_222_WebUI_ユーザー番号);

     //ID7_1_223_[この設定で変更]にて、法人編集可能なこと
        AdminDukeMod.ログイン名_メールアドレス.テキストを上書き("cpiautouser1@test.tes");
        AdminDukeMod.この設定で変更する.スクロール();
        AdminDukeMod.この設定で変更する.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_223_個別アカウント編集画面_メールアドレス);

     //ID7_1_224_個別アカウント一覧にログイン名(メールアドレス)が表示されていること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ログイン名編集.表示文言を検証("cpiautouser1@test.test");

        ReportCsv.chekedOK(CsvRecords.ID7_1_224_個別アカウント一覧画面_メールアドレス);

     //ID7_1_225_WebUIで変更したログイン名(メールアドレス）にて、ログインできること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_225_WebUI_メールアドレス);

        AdminDukeList.ユーザー番号1.スクロール(); //元の値に戻す処理
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ログイン名_メールアドレス.表示文言を検証("autouser1@test.test");
        AdminDukeMod.この設定で変更する.クリック();

     //ID7_1_226_アカウント作成時に指定したニックネームが表示されていること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ニックネーム.表示文言を検証("自動個別アカウント");

        ReportCsv.chekedOK(CsvRecords.ID7_1_226_個別アカウント編集画面_ニックネーム);

      //ID7_1_227_ニックネームが編集不可であること
        AdminDukeMod.ニックネーム.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_227_個別アカウント編集画面_ニックネーム);

     //ID7_1_228_WebUIログイン後画面に指定したニックネームが反映されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_228_WebUI_ニックネーム);

     //ID7_1_229_[この設定で変更]にて、法人編集可能なこと
        //AdminDukeList.ユーザー番号1.スクロール();
        //AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.ファイル保管日数.テキストを上書き("9");
        AdminDukeMod.この設定で変更する.クリック();

        ReportCsv.chekedOK(CsvRecords.ID7_1_229_個別アカウント編集画面_ファイル保管日数);

     //ID7_1_230_ファイル保管日数内のファイルが削除されないこと
        //ReportCsv.chekedOK(CsvRecords.ID7_1_230_WebUI_ファイル保管日数_期限内);

     //ID7_1_231_ファイル保管日数経過でファイルが削除されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_231_WebUI_ファイル保管日数_期限経過);

     //ID7_1_232_設定変更が不可であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.編集不可状態であるかの検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_232_個別アカウント編集画面_ログイン方法);

     //ID7_1_233_「ユーザー番号のみまたはログイン名とパスワードでログインする。」が表示されていること
        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.表示文言を検証("ユーザー番号のみまたはログイン名とパスワードでログインする。");

        ReportCsv.chekedOK(CsvRecords.ID7_1_233_個別アカウント編集画面_ログイン方法);

        AdminDukeMod.キャンセル.クリック();

     //ID7_1_234_「ユーザー番号のみでのログインを禁止し、常にログイン名とパスワードでログインする。」が表示されていること
        AdminDukeList.ユーザー番号2.スクロール();
        AdminDukeList.ユーザー番号2.クリック();

        AdminDukeMod.店舗にあるマルチコピー機でのログイン方法.表示文言を検証("ユーザー番号のみでのログインを禁止し、常にログイン名とパスワードでログインする。");

        ReportCsv.chekedOK(CsvRecords.ID7_1_234_個別アカウント編集画面_ログイン方法);

     //ID7_1_235_(appdb)prnsys_appkey_costmizeのappキーがリストに表示されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_235_個別アカウント編集画面_後課金_コピー機画面カスタマイズ設定);

     //ID7_1_236_パスワード有効期限が切れた場合(180日経過後)、パスワード変更画面が表示されること
        //ReportCsv.chekedOK(CsvRecords.ID7_1_236_WebUI_パスワード有効期限_期限切れ);

     //ID7_1_237_180日経過後、パスワード変更画面が表示されないこと
        //ReportCsv.chekedOK(CsvRecords.ID7_1_237_WebUI_パスワード有効期限_期限内);

     //ID7_1_238_パスワードの有効期限(180日間)を設定するのチェックボックスが有効であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(true);

        ReportCsv.chekedOK(CsvRecords.ID7_1_238_個別アカウント編集画面_パスワード有効期限);

        AdminDukeMod.パスワード有効期限設定.チェックボックス選択(false);
        AdminDukeMod.この設定で変更する.クリック();


     //ID7_1_239_パスワードの有効期限(180日間)を設定するのチェックボックスが無効であること
        AdminDukeList.ユーザー番号1.スクロール();
        AdminDukeList.ユーザー番号1.クリック();
        AdminDukeMod.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

        ReportCsv.chekedOK(CsvRecords.ID7_1_239_個別アカウント編集画面_パスワード有効期限);

    	close();
    }

}
