package old;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.remote.BrowserType;
import org.sahagin.runlib.external.PageDoc;

import sbc.uitesttool.selenide.pageparts.AdminCorpAdd;
import sbc.uitesttool.selenide.pageparts.AdminCorpAddByContents;
import sbc.uitesttool.selenide.pageparts.AdminCorpAddByLite;
import sbc.uitesttool.selenide.pageparts.AdminCorpList;
import sbc.uitesttool.selenide.pageparts.AdminCorpMod;
import sbc.uitesttool.selenide.report.ReportCsv;
import sbc.uitesttool.selenide.report.ScreenShot;
import sbc.uitesttool.selenide.report.records.CsvRecords;

import com.codeborne.selenide.Configuration;

//TODO:enumの処理共通化

@PageDoc("法人アカウント.法人アカウント一覧")
public class CorpListTest_Sample {
    // TODO:後で共通化する
    private static final String BASE_URL = "https://cvs.so.sh.airfolc.co.jp/forBiz/admin/app";

    @BeforeClass
    public static void beforeClass() {
	Configuration.browser = BrowserType.CHROME;
	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
    }

    @AfterClass
    public static void afterClass() {
	ReportCsv.outputCsv();
    }

    @Test
    public void 法人アカウント一覧のテスト_一覧表示() throws InterruptedException, IOException {
	open(BASE_URL);

    //ScreenShot.takesScreenshot("法人アカウント一覧画面.png");

    //ID7_1_1_法人アカウント一覧に[ユーザー番号のプレフィックス]が表示されていること
  		AdminCorpList.ユーザー番号のプレフィックス.スクロール();
  		AdminCorpList.ユーザー番号のプレフィックス.表示文言を検証("))8");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_1_法人アカウント一覧表示確認);

      //ID7_1_2_法人アカウント一覧に[企業名]が表示されていること
  		AdminCorpList.企業名.表示文言を検証("自動テスト1");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_2_法人アカウント一覧表示確認);

      //ID7_1_3_法人アカウント編集画面にてタイトルに[法人アカウント編集]が表示されていること
  		//AdminCorpMod.法人アカウント編集_タイトル.画像のaltを検証("法人アカウント編集");

  		//ReportCsv.chekedOK(CsvRecords.ID7_1_3_法人アカウント編集_タイトル名);

      //ID7_1_4_法人アカウント編集画面にて[企業名]が表示されていること
  		AdminCorpList.企業名.クリック();
  		AdminCorpMod.企業名.セットされた値を検証("自動テスト1");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_4_法人アカウント編集_企業名);

  			ScreenShot.takesScreenshot("法人アカウント編集画面.png");

  		AdminCorpMod.キャンセル.クリック();

  		AdminCorpList.新規法人アカウントを追加ボタン.スクロール(); // ボタンのある位置までスクロール（スクロールしないとボタン押せない）
  		AdminCorpList.新規法人アカウントを追加ボタン.クリック();

      //ID7_1_5_法人アカウント追加画面追加画面のタイトルに[法人アカウント追加画面追加]が表示されていること
  		//AdminCorpAdd.法人アカウント追加_タイトル.画像のaltを検証;
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_5_法人アカウント追加_タイトル名);

      //ID7_1_6_法人アカウント追加画面にユーザー番号のプレフィックス_項目が表示されること
  		AdminCorpAdd.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_6_法人アカウント追加_ユーザー番号のプレフィックス項目);

      //ID7_1_7_法人アカウント追加画面に企業名_項目が表示されること
  		AdminCorpAdd.企業名_項目.表示文言を検証("企業名");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_7_法人アカウント追加_企業名項目);

      //ID7_1_8_法人アカウント追加画面にメールアドレス_項目が表示されること
  		AdminCorpAdd.メールアドレス_項目.表示文言を検証("メールアドレス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_8_法人アカウント追加_メールアドレス項目);

      //ID7_1_9_法人アカウント追加画面にパスワード_項目が表示されること
  		AdminCorpAdd.パスワード_項目.表示文言を検証("パスワード");

  		//AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);
  		//AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
  		//AdminCorpAdd.パスワード_テキストボックス.セットされた値を検証("cpi12345");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_9_法人アカウント追加_パスワード項目);

      //ID7_1_10_法人アカウント追加画面に契約期間_項目が表示されること
  		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_10_法人アカウント追加_契約期間項目);

      //ID7_1_11_法人アカウント追加画面の最大登録数_項目が表示されること
  		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_11_法人アカウント追加_法人アカウント追加画面の最大登録数項目);

      //ID7_1_12_法人アカウント追加画面に法人種別_項目が表示されること
  		AdminCorpAdd.法人種別_項目.表示文言を検証("法人種別");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_12_法人アカウント追加_法人種別項目);

      //ID7_1_13_法人アカウント追加画面にファイルロギング設定_項目が表示されること
  		AdminCorpAdd.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_13_法人アカウント追加_ファイルロギング設定項目);

      //ID7_1_14_法人アカウント追加画面に_後課金_コピー機画面カスタマイズ設定項目が表示されること
  		AdminCorpAdd.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_14_法人アカウント追加_後課金_コピー機画面カスタマイズ設定項目);

      //ID7_1_15_法人アカウント追加画面に_初回ログイン時パスワード強制変更項目が表示されること
  		AdminCorpAdd.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_15_法人アカウント追加_初回ログイン時パスワード強制変更項目);

      //ID7_1_16_法人アカウント追加画面に_アカウント設定禁止項目が表示されること
  		AdminCorpAdd.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_16_法人アカウント追加_アカウント設定禁止項目);

      //ID7_1_17_法人アカウント追加画面に_外部クラウドサービスとの連携項目が表示されること
  		AdminCorpAdd.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_17_法人アカウント追加_外部クラウドサービスとの連携項目);

  			ScreenShot.takesScreenshot("法人アカウント追加画面.png");

      //ID7_1_18_ユーザー番号のプレフィックスに設定値が入力され正しく表示されていること
  		AdminCorpAdd.ユーザー番号のプレフィックス.テキストに追記("AT1");
  		AdminCorpAdd.ユーザー番号のプレフィックス.セットされた値を検証("AT1");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_18_法人アカウント追加_ユーザー番号のプレフィックス);

      //ID7_1_19_企業名に設定値が入力され正しく表示されていること
  		AdminCorpAdd.企業名.テキストに追記("自動テスト1");
  		AdminCorpAdd.企業名.セットされた値を検証("自動テスト1");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_19_法人アカウント追加_企業名);

      //ID7_1_20_メールアドレスに設定値が入力され正しく表示されていること
  		AdminCorpAdd.メールアドレス.テキストに追記("autotest@test.test");
  		AdminCorpAdd.メールアドレス.セットされた値を検証("autotest@test.test");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_20_法人アカウント追加_メールアドレス);

      //ID7_1_21_パスワードの入力が行えないこと
  		AdminCorpAdd.パスワード_テキストボックス.編集不可状態であるかの検証(true);

  		ReportCsv.chekedOK(CsvRecords.ID7_1_21_法人アカウント追加_パスワード入力不可);

      //ID7_1_22_パスワードのチェックボックスが有効にできること
  		AdminCorpAdd.パスワード_チェックボックス.チェックボックス選択(true);

  		ReportCsv.chekedOK(CsvRecords.ID7_1_22_法人アカウント追加_パスワード_チェックボックス);

      //ID7_1_23_パスワードの入力が行えること
  		AdminCorpAdd.パスワード_テキストボックス.テキストを上書き("cpi12345");
  		AdminCorpAdd.パスワード_テキストボックス.セットされた値を検証("cpi12345");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_23_法人アカウント追加_パスワード_テキストボックス);

      //ID7_1_24_契約期間に設定値が入力され正しく表示されていること
  		AdminCorpAdd.契約期間.テキストを上書き("100");
  		AdminCorpAdd.契約期間.セットされた値を検証("100");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_24_法人アカウント追加_契約期間);

      //ID7_1_25_法人アカウントの最大登録数に設定値が入力され正しく表示されていること
  		AdminCorpAdd.法人アカウントの最大登録数.テキストを上書き("89");
  		AdminCorpAdd.法人アカウントの最大登録数.セットされた値を検証("89");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_25_法人アカウント追加_法人アカウントの最大登録数);

      //ID7_1_26_法人種別forBiz用法人に設定されていること
  		AdminCorpAdd.法人種別.Selectボックス選択("forBiz用法人");
  		AdminCorpAdd.法人種別.表示文言を検証("forBiz用法人");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_26_法人アカウント追加_法人種別);

      //ID7_1_27_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること
  		AdminCorpAdd.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_27_法人アカウント追加_ユーザー番号のプレフィックス_項目);

  	//ID7_1_28_法人アカウント項目に企業名_項目が表示されていること
  		AdminCorpAdd.企業名_項目.表示文言を検証("企業名");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_28_法人アカウント追加_企業名_項目);

      //ID7_1_29_法人アカウント項目にメールアドレス_項目が表示されていること
  		AdminCorpAdd.メールアドレス_項目.表示文言を検証("メールアドレス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_29_法人アカウント追加_メールドレス_項目);

      //ID7_1_30_法人アカウント項目にパスワード_項目が表示されていること
  		AdminCorpAdd.パスワード_項目.表示文言を検証("パスワード");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_30_法人アカウント追加_パスワード_項目);

      //ID7_1_31_法人アカウント項目に契約期間_項目が表示されていること
  		AdminCorpAdd.契約期間_項目.表示文言を検証("契約期間");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_31_法人アカウント追加_契約期間_項目);

      //ID7_1_32_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
  		AdminCorpAdd.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_32_法人アカウント追加_法人アカウントの最大登録数_項目);

      //ID7_1_33_法人アカウント項目に法人種別_項目が表示されていること
  		AdminCorpAdd.法人種別_項目.表示文言を検証("法人種別");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_33_法人アカウント追加_法人種別_項目);

      //ID7_1_34_法人アカウント項目にファイルロギング設定_項目が表示されていること
  		AdminCorpAdd.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_34_法人アカウント追加_ファイルロギング設定_項目);

      //ID7_1_35_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
  		AdminCorpAdd.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_35_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

      //ID7_1_36_法人アカウント項目に初回ログイン時パスワード強制変更_項目が表示されていること
  		AdminCorpAdd.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_36_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

      //ID7_1_37_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
  		AdminCorpAdd.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_37_法人アカウント追加_パスワード有効期限設定_項目);

      //ID7_1_38_法人アカウント項目にアカウント設定禁止_項目が表示されていること
  		AdminCorpAdd.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_38_法人アカウント追加_アカウント設定禁止_項目);

      //ID7_1_39_法人アカウント項目に外部クラウドサービスとの連携_項目が表示されていること
  		AdminCorpAdd.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_39_法人アカウント追加_外部クラウドサービスとの連携_項目);

      //ID7_1_40_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_40_法人アカウント追加_法人アカウントの現在登録数_項目);

      //ID7_1_41_法人アカウント項目にクリックラップ契約_項目が非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_41_法人アカウント追加_クリックラップ契約_項目);

      //ID7_1_42_法人アカウント項目に印刷料金を価格情報ファイルから設定するが非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_42_法人アカウント追加_印刷料金を価格情報ファイルから設定);

      //ID7_1_43_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_43_法人アカウント追加_法人管理アカウント情報_項目);

 		ScreenShot.takesScreenshot("法人アカウント追加画面_forBiz用法人.png");

  	//ID7_1_44_法人種別forBizLite用法人が選択できること
  		AdminCorpAdd.法人種別.Selectボックス選択("forBizLite用法人");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_44_法人アカウント追加_法人種別forBizLite用法人);

  	//ID7_1_45_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること_forBizLite用法人
  		AdminCorpAddByLite.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_45_法人アカウント追加_ユーザー番号のプレフィックス_項目);

      //ID7_1_46_法人アカウント項目に企業名_項目が表示されていること
  		AdminCorpAddByLite.企業名_項目.表示文言を検証("企業名");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_46_法人アカウント追加_企業名_項目);

      //ID7_1_47_法人アカウント項目にメールアドレス_項目が表示されていること
  		AdminCorpAddByLite.メールアドレス_項目.表示文言を検証("メールアドレス");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_47_法人アカウント追加_メールアドレス_項目);

      //ID7_1_48_法人アカウント項目にパスワード_項目が表示されていること
  		AdminCorpAddByLite.パスワード_項目.表示文言を検証("パスワード");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_48_法人アカウント追加_パスワード_項目);

      //ID7_1_49_法人アカウント項目に契約期間_項目が表示されていること
  		AdminCorpAddByLite.契約期間_項目.表示文言を検証("契約期間");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_49_法人アカウント追加_契約期間_項目);

      //ID7_1_50_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
  		AdminCorpAddByLite.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_50_法人アカウント追加_法人アカウントの最大登録数_項目);

      //ID7_1_51_法人アカウント項目に法人種別_項目が表示されていること
  		AdminCorpAddByLite.法人種別_項目.表示文言を検証("法人種別");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_51_法人アカウント追加_法人種別_項目);

      //ID7_1_52_法人アカウント項目にファイルロギング設定_項目が表示されていること
  		AdminCorpAddByLite.ファイルロギング設定_項目.表示文言を検証("ファイルロギング設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_52_法人アカウント追加_ファイルロギング設定_項目);

      //ID7_1_53_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
  		AdminCorpAddByLite.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_53_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

      //ID7_1_54_法人アカウント項目に初回ログイン時パスワード強制変更_項目が表示されていること
  		AdminCorpAddByLite.初回ログイン時パスワード強制変更_項目.表示文言を検証("初回ログイン時パスワード強制変更");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_54_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

      //ID7_1_55_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
  		AdminCorpAddByLite.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_55_法人アカウント追加_パスワード有効期限設定_項目);

      //ID7_1_56_法人アカウント項目に印刷料金を価格情報ファイルから設定するが表示されていること
  		AdminCorpAddByLite.印刷料金を価格情報ファイルから設定する_項目.表示文言を検証("印刷料金を価格情報ファイルから設定する");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_56_印刷料金を価格情報ファイルから設定_項目);

      //ID7_1_57_法人アカウント項目にアカウント設定禁止_項目が表示されていること
  		AdminCorpAddByLite.アカウント設定禁止_項目.表示文言を検証("アカウント設定禁止");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_57_法人アカウント追加_アカウント設定禁止_項目);

      //ID7_1_58_法人アカウント項目に外部クラウドサービスとの連携_項目が表示されていること
  		AdminCorpAddByLite.外部クラウドサービスとの連携_項目.表示文言を検証("外部クラウドサービスとの連携");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_58_法人アカウント追加_外部クラウドサービスとの連携_項目);

      //ID7_1_59_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_59_法人アカウント追加_法人アカウントの現在登録数_項目);

      //ID7_1_60_法人アカウント項目にクリックラップ契約_項目が非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_60_法人アカウント追加_クリックラップ契約_項目);

      //ID7_1_61_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
  		//ReportCsv.chekedOK(CsvRecords.ID7_1_61_法人アカウント追加_法人管理アカウント情報_項目);

 		ScreenShot.takesScreenshot("法人アカウント追加画面_forBizLite用法人.png");

  	  //ID7_1_62_法人種別コンテンツ利用用法人が選択できること
  		AdminCorpAdd.法人種別.Selectボックス選択("コンテンツ利用用法人");

  		ReportCsv.chekedOK(CsvRecords.ID7_1_62_法人アカウント追加_法人種別コンテンツ利用用法人);

      //ID7_1_63_法人アカウント項目にユーザー番号のプレフィックス_項目が表示されていること_コンテンツ利用用法人
  		AdminCorpAddByContents.ユーザー番号のプレフィックス_項目.表示文言を検証("ユーザー番号のプレフィックス");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_63_法人アカウント追加_ユーザー番号のプレフィックス_項目);

      //ID7_1_64_法人アカウント項目に企業名_項目が表示されていること
   	  	AdminCorpAddByContents.企業名_項目.表示文言を検証("企業名");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_64_法人アカウント追加_企業名_項目);

      //ID7_1_65_法人アカウント項目にメールアドレス_項目が表示されていること
   	  	AdminCorpAddByContents.メールアドレス_項目.表示文言を検証("メールアドレス");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_65_法人アカウント追加_メールアドレス_項目);

      //ID7_1_66_法人アカウント項目にパスワード_項目が表示されていること
   	  	AdminCorpAddByContents.パスワード_項目.表示文言を検証("パスワード");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_66_法人アカウント追加_スワード_項目);

      //ID7_1_67_法人アカウント項目に契約期間_項目が表示されていること
   	  	AdminCorpAddByContents.契約期間_項目.表示文言を検証("契約期間");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_67_法人アカウント追加_契約期間_項目);

      //ID7_1_68_法人アカウント項目に法人アカウントの最大登録数_項目が表示されていること
   	  	AdminCorpAddByContents.法人アカウントの最大登録数_項目.表示文言を検証("法人アカウントの最大登録数");

   	 	ReportCsv.chekedOK(CsvRecords.ID7_1_68_法人アカウント追加_法人アカウントの最大登録数_項目);

      //ID7_1_69_法人アカウント項目に法人種別_項目が表示されていること
   	 	AdminCorpAddByContents.法人種別_項目.表示文言を検証("法人種別");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_69_法人アカウント追加_法人種別_項目);

      //ID7_1_70_法人アカウント項目に後課金_コピー機画面カスタマイズ設定_項目が表示されていること
   	  	AdminCorpAddByContents.後課金_コピー機画面カスタマイズ設定_項目.表示文言を検証("後課金/コピー機画面カスタマイズ設定");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_70_法人アカウント追加_後課金_コピー機画面カスタマイズ設定_項目);

      //ID7_1_71_法人アカウント項目にパスワード有効期限設定_項目が表示されていること
   	  	AdminCorpAddByContents.パスワード有効期限設定_項目.表示文言を検証("パスワード有効期限設定");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_71_法人アカウント追加_パスワード有効期限設定_項目);

      //ID7_1_72_法人アカウント項目に法人アカウントの現在登録数_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_72_法人アカウント追加_法人アカウントの現在登録数_項目);

      //ID7_1_73_法人アカウント項目にクリックラップ契約_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_73_法人アカウント追加_クリックラップ契約_項目);

      //ID7_1_74_法人アカウント項目にファイルロギング設定_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_74_法人アカウント追加_ファイルロギング設定_項目);

      //ID7_1_75_法人アカウント項目に初回ログイン時パスワード強制変更_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_75_法人アカウント追加_初回ログイン時パスワード強制変更_項目);

      //ID7_1_76_法人アカウント項目に印刷料金を価格情報ファイルから設定するが非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_76_法人アカウント追加_印刷料金を価格情報ファイルから設定_項目);

      //ID7_1_77_法人アカウント項目にアカウント設定禁止_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_77_法人アカウント追加_アカウント設定禁止_項目);

      //ID7_1_78_法人アカウント項目に外部クラウドサービスとの連携_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_78_法人アカウント追加_外部クラウドサービスとの連携_項目);

      //ID7_1_79_法人アカウント項目に法人管理アカウント情報_項目が非表示であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_79_法人アカウント追加_法人管理アカウント情報_項目);

   	  	AdminCorpAddByContents.法人種別.Selectボックス選択("forBiz用法人");

      //ID7_1_80_法人アカウント項目_ファイルロギング設定のチェックボックスを無効にできること
   	  	AdminCorpAdd.ファイルロギング設定.チェックボックス選択(false);
   	  	AdminCorpAdd.ファイルロギング設定.チェックボックスがチェックされているかを検証(false);

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_80_法人アカウント追加_ファイルロギング設定);

      //ID7_1_81_法人アカウント項目_後課金_コピー機画面カスタマイズ設定のベンダー課金を選択できること
   	  	AdminCorpAdd.後課金_コピー機画面カスタマイズ設定.Selectボックス選択("ベンダー課金（標準価格）・標準設定");

   	  	ReportCsv.chekedOK(CsvRecords.ID7_1_81_法人アカウント追加_後課金_コピー機画面カスタマイズ設定);

      //ID7_1_82_forBiz用法人向けのappキーがリストに表示されること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_82_法人アカウント追加_forBiz用法人リスト);

      //ID7_1_83_forBizLite用法人向けのappキーがリストに表示されること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_83_法人アカウント追加_forBizLite用法人リスト);

      //ID7_1_84_コンテンツ利用用法人向けのappキーがリストに表示されること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_84_法人アカウント追加_コンテンツ利用法人リスト);

      //ID7_1_85_appキーの追加_削除が可能であること
   	  	//ReportCsv.chekedOK(CsvRecords.ID7_1_85_法人アカウント追加_appキー追加_削除);

      //ID7_1_86_初回ログイン時パスワード強制変更のチェックボックスを無効にできること
      	AdminCorpAdd.初回ログイン時パスワード強制変更.チェックボックス選択(false);
      	AdminCorpAdd.初回ログイン時パスワード強制変更.チェックボックスがチェックされているかを検証(false);

      ReportCsv.chekedOK(CsvRecords.ID7_1_86_法人アカウント追加_初回ログイン時パスワード強制変更);

      //ID7_1_88_パスワード有効期限設定のチェックボックスを無効にできること
      	AdminCorpAdd.パスワード有効期限設定.チェックボックス選択(false);
      	AdminCorpAdd.パスワード有効期限設定.チェックボックスがチェックされているかを検証(false);

      ReportCsv.chekedOK(CsvRecords.ID7_1_88_法人アカウント追加_パスワード有効期限設定);

      //ID7_1_90_アカウント設定禁止のチェックボックスを無効にできること
      	AdminCorpAdd.アカウント設定禁止.チェックボックス選択(false);
      	AdminCorpAdd.アカウント設定禁止.チェックボックスがチェックされているかを検証(false);

      ReportCsv.chekedOK(CsvRecords.ID7_1_90_法人アカウント追加_アカウント設定禁止);

      //ID7_1_92_外部クラウドサービスとの連携を[指定しない]に選択できること
      	AdminCorpAdd.外部クラウドサービスとの連携.Selectボックス選択("指定しない");

      	ReportCsv.chekedOK(CsvRecords.ID7_1_92_法人アカウント追加_外部クラウドサービスとの連携);

      		ScreenShot.takesScreenshot("法人アカウント追加画面_コンテンツ利用用法人.png");

	close();
    }

}
